<section class="sptb">
   <div class="container">
      <div class="text-justify">
         <h2 class="mb-4 font-weight-semibold">Why Eudica?</h2>
         <h5 class="leading-normal">Majority have suffered alteration in some form, by injected humor</h5>
         <p class="leading-normal text-muted">There are many variations of passages of Lorem Ipsum available, but the majority have suffered by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to as necessary All the Lorem Ipsum generators on the Internet tend to repeat</p>
         <p class="leading-normal text-muted">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
         <p class="leading-normal mb-0 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      </div>
   </div>
</section>


<!--<section class="sptb bg-white">
   <div class="container">
      <div class="section-title center-block text-center">
         <h2>How It Works?</h2>
         <span class="sectiontitle-design"><span class="icons"></span></span> 
         <p>Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
      </div>
      <div class="row">
         <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="">
               <div class="mb-lg-0 mb-4">
                  <div class="service-card text-center">
                     <div class="icon-bg box-shadow icon-service text-purple about"> <img src="../assets/images/png/about/employees.png" alt="img"> </div>
                     <div class="servic-data mt-3">
                        <h4 class="font-weight-semibold mb-2">Register</h4>
                        <p class="text-muted mb-0">Nam libero tempore, cum soluta nobis est eligendi cumque facere possimus</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="">
               <div class="mb-lg-0 mb-4">
                  <div class="service-card text-center">
                     <div class=" icon-bg box-shadow icon-service text-purple about"> <img src="../assets/images/png/about/megaphone.png" alt="img"> </div>
                     <div class="servic-data mt-3">
                        <h4 class="font-weight-semibold mb-2">Create Account</h4>
                        <p class="text-muted mb-0">Nam libero tempore, cum soluta nobis est eligendi cumque facere possimus</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="">
               <div class="mb-sm-0 mb-4">
                  <div class="service-card text-center">
                     <div class="icon-bg box-shadow icon-service text-purple about"> <img src="../assets/images/png/about/pencil.png" alt="img"> </div>
                     <div class="servic-data mt-3">
                        <h4 class="font-weight-semibold mb-2">Coursed Posts</h4>
                        <p class="text-muted mb-0">Nam libero tempore, cum soluta nobis est eligendi cumque facere possimus</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="">
               <div class="">
                  <div class="service-card text-center">
                     <div class="icon-bg box-shadow icon-service text-purple about"> <img src="../assets/images/png/about/coins.png" alt="img"> </div>
                     <div class="servic-data mt-3">
                        <h4 class="font-weight-semibold mb-2">Get Earnings</h4>
                        <p class="text-muted mb-0">Nam libero tempore, cum soluta nobis est eligendi cumque facere possimus</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>-->