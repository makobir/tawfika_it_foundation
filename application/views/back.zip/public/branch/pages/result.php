<section class="sptb">
   <div class="container customerpage">
      <div class="row">
         <div class="single-page">
            <div class="col-lg-6 col-xl-4 col-xl-offset-3 col-md-6 center-result">
               <div class="wrapper wrapper2">
                  <form class="card-body" tabindex="500" method="post" action="<?= base_url() ?>home/result_check">
                     <h3>Result</h3>
                     <div class="mail"> <input style="color: #000" type="text" name="regi"> <label>Enter Registration Number</label> </div>
                     <div class="submit"> <button class="btn btn-primary btn-block" type="submit">View Result</button> </div>
                     <!--<p class="text-dark mb-0">Don't have account?<a href="register.html" class="text-primary ml-1">Sign UP</a></p>-->
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>