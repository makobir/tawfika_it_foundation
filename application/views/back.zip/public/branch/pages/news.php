<section class="sptb bg-white">
   <div class="container">
      <!--<div class="section-title center-block text-center">
         <h2>News</h2>
         <span class="sectiontitle-design"><span class="icons"></span></span> 
         <p>Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
      </div>-->
      <div id="defaultCarousel" class="owl-carousel Card-owlcarousel owl-carousel-icons owl-loaded owl-drag">
         <div class="owl-stage-outer">
            <div class="owl-stage" style="transform: translate3d(-2402px, 0px, 0px); transition: all 0.25s ease 0s; width: 4805px;">
               <div class="owl-item cloned" style="width: 375.337px; margin-right: 25px;">
                  <div class="item">
                     <div class="card mb-0">
                        <div class="item7-card-img"> <a href="<?= base_url() ?>home/news_detail"></a> <img src="<?= base_url() ?>upload/news/download (1).jpg" alt="img" class="cover-image"> </div>
                        <div class="card-body p-4">
                           <div class="item7-card-desc d-flex mb-2">
                              <a href="#"><i class="fa fa-calendar-o mr-2"></i>Dec-03-2018</a> 
                              <div class="ml-auto"> <a href="#"><i class="fa fa-comment-o mr-2"></i>4 Comments</a> </div>
                           </div>
                           <a href="blog-details.html" class="text-dark">
                              <h3 class="font-weight-semibold">Excepteur occaecat cupidatat</h3>
                           </a>
                           <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat </p>
                           <div class="d-flex align-items-center pt-2 mt-auto">
                              <img src="<?= base_url() ?>upload/news/download (1).jpg" class="avatar brround avatar-md mr-3" alt="avatar-img"> 
                              <div> <a href="profile.html" class="text-default">Royal Hamblin</a> <small class="d-block text-muted">10 days ago</small> </div>
                              <div class="ml-auto text-muted"> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fa fa-thumbs-o-up"></i></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="owl-item cloned" style="width: 375.337px; margin-right: 25px;">
                  <div class="item">
                     <div class="card mb-0">
                        <div class="item7-card-img"> <a href="#"></a> <img src="<?= base_url() ?>upload/news/download (1).jpg" alt="img" class="cover-image"> </div>
                        <div class="card-body p-4">
                           <div class="item7-card-desc d-flex mb-2">
                              <a href="#"><i class="fa fa-calendar-o mr-2"></i>Nov-28-2018</a> 
                              <div class="ml-auto"> <a href="#"><i class="fa fa-comment-o mr-2"></i>2 Comments</a> </div>
                           </div>
                           <a href="blog-details.html" class="text-dark">
                              <h3 class="font-weight-semibold">Sed ut perspiciatis iste</h3>
                           </a>
                           <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat </p>
                           <div class="d-flex align-items-center pt-2 mt-auto">
                              <img src="<?= base_url() ?>upload/news/download (1).jpg" class="avatar brround avatar-md mr-3" alt="avatar-img"> 
                              <div> <a href="profile.html" class="text-default">Rosita Chatmon</a> <small class="d-block text-muted">10 days ago</small> </div>
                              <div class="ml-auto text-muted"> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fa fa-thumbs-o-up"></i></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="owl-item cloned" style="width: 375.337px; margin-right: 25px;">
                  <div class="item">
                     <div class="card mb-0">
                        <div class="item7-card-img"> <a href="#"></a> <img src="<?= base_url() ?>upload/news/download (1).jpg" alt="img" class="cover-image"> </div>
                        <div class="card-body p-4">
                           <div class="item7-card-desc d-flex mb-2">
                              <a href="#"><i class="fa fa-calendar-o mr-2"></i>Nov-19-2018</a> 
                              <div class="ml-auto"> <a href="#"><i class="fa fa-comment-o text-muted mr-2"></i>8 Comments</a> </div>
                           </div>
                           <a href="blog-details.html" class="text-dark">
                              <h3 class="font-weight-semibold">At vero accusamus et iusto</h3>
                           </a>
                           <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat </p>
                           <div class="d-flex align-items-center pt-2 mt-auto">
                              <img src="<?= base_url() ?>upload/news/download (1).jpg" class="avatar brround avatar-md mr-3" alt="avatar-img"> 
                              <div> <a href="profile.html" class="text-default">Loyd Nolf</a> <small class="d-block text-muted">15 days ago</small> </div>
                              <div class="ml-auto text-muted"> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fa fa-thumbs-o-up"></i></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="owl-item" style="width: 375.337px; margin-right: 25px;">
                  <div class="item">
                     <div class="card mb-0">
                        <div class="item7-card-img"> <a href="#"></a> <img src="<?= base_url() ?>upload/news/download (1).jpg" alt="img" class="cover-image"> </div>
                        <div class="card-body p-4">
                           <div class="item7-card-desc d-flex mb-2">
                              <a href="#"><i class="fa fa-calendar-o mr-2"></i>Dec-03-2018</a> 
                              <div class="ml-auto"> <a href="#"><i class="fa fa-comment-o mr-2"></i>4 Comments</a> </div>
                           </div>
                           <a href="blog-details.html" class="text-dark">
                              <h3 class="font-weight-semibold">Nemo enim ipsam voluptatem</h3>
                           </a>
                           <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat </p>
                           <div class="d-flex align-items-center pt-2 mt-auto">
                              <img src="<?php echo base_url() ?>assets/branch/images/users/male/5.jpg" class="avatar brround avatar-md mr-3" alt="avatar-img"> 
                              <div> <a href="profile.html" class="text-default">Joanne Nash</a> <small class="d-block text-muted">1 day ago</small> </div>
                              <div class="ml-auto text-muted"> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fa fa-thumbs-o-up"></i></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="owl-item" style="width: 375.337px; margin-right: 25px;">
                  <div class="item">
                     <div class="card mb-0">
                        <div class="item7-card-img"> <a href="#"></a> <img src="<?= base_url() ?>upload/news/download (1).jpg" alt="img" class="cover-image"> </div>
                        <div class="card-body p-4">
                           <div class="item7-card-desc d-flex mb-2">
                              <a href="#"><i class="fa fa-calendar-o mr-2"></i>Nov-28-2018</a> 
                              <div class="ml-auto"> <a href="#"><i class="fa fa-comment-o mr-2"></i>2 Comments</a> </div>
                           </div>
                           <a href="blog-details.html" class="text-dark">
                              <h3 class="font-weight-semibold">Sed ut perspiciatis unde iste</h3>
                           </a>
                           <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat </p>
                           <div class="d-flex align-items-center pt-2 mt-auto">
                              <img src="<?php echo base_url() ?>assets/branch/images/users/male/7.jpg" class="avatar brround avatar-md mr-3" alt="avatar-img"> 
                              <div> <a href="profile.html" class="text-default">Tanner Mallari</a> <small class="d-block text-muted">2 days ago</small> </div>
                              <div class="ml-auto text-muted"> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fa fa-thumbs-o-up"></i></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="owl-item" style="width: 375.337px; margin-right: 25px;">
                  <div class="item">
                     <div class="card mb-0">
                        <div class="item7-card-img"> <a href="#"></a> <img src="<?= base_url() ?>upload/news/download (1).jpg" alt="img" class="cover-image"> </div>
                        <div class="card-body p-4">
                           <div class="item7-card-desc d-flex mb-2">
                              <a href="#"><i class="fa fa-calendar-o mr-2"></i>Nov-19-2018</a> 
                              <div class="ml-auto"> <a href="#"><i class="fa fa-comment-o text-muted mr-2"></i>8 Comments</a> </div>
                           </div>
                           <a href="blog-details.html" class="text-dark">
                              <h3 class="font-weight-semibold">At vero eos et accusamus</h3>
                           </a>
                           <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat </p>
                           <div class="d-flex align-items-center pt-2 mt-auto">
                              <img src="<?= base_url() ?>upload/news/download (1).jpg" class="avatar brround avatar-md mr-3" alt="avatar-img"> 
                              <div> <a href="profile.html" class="text-default">Aracely Bashore</a> <small class="d-block text-muted">5 days ago</small> </div>
                              <div class="ml-auto text-muted"> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fa fa-thumbs-o-up"></i></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="owl-item active" style="width: 375.337px; margin-right: 25px;">
                  <div class="item">
                     <div class="card mb-0">
                        <div class="item7-card-img"> <a href="#"></a> <img src="<?php echo base_url() ?>assets/branch/images/media/0-5.jpg" alt="img" class="cover-image"> </div>
                        <div class="card-body p-4">
                           <div class="item7-card-desc d-flex mb-2">
                              <a href="#"><i class="fa fa-calendar-o mr-2"></i>Nov-28-2018</a> 
                              <div class="ml-auto"> <a href="#"><i class="fa fa-comment-o mr-2"></i>2 Comments</a> </div>
                           </div>
                           <a href="blog-details.html" class="text-dark">
                              <h3 class="font-weight-semibold">Sed ut perspiciatis iste</h3>
                           </a>
                           <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat </p>
                           <div class="d-flex align-items-center pt-2 mt-auto">
                              <img src="<?php echo base_url() ?>assets/branch/images/users/female/5.jpg" class="avatar brround avatar-md mr-3" alt="avatar-img"> 
                              <div> <a href="profile.html" class="text-default">Rosita Chatmon</a> <small class="d-block text-muted">10 days ago</small> </div>
                              <div class="ml-auto text-muted"> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fa fa-thumbs-o-up"></i></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="owl-item active" style="width: 375.337px; margin-right: 25px;">
                  <div class="item">
                     <div class="card mb-0">
                        <div class="item7-card-img"> <a href="#"></a> <img src="<?php echo base_url() ?>assets/branch/images/media/0-6.jpg" alt="img" class="cover-image"> </div>
                        <div class="card-body p-4">
                           <div class="item7-card-desc d-flex mb-2">
                              <a href="#"><i class="fa fa-calendar-o mr-2"></i>Nov-19-2018</a> 
                              <div class="ml-auto"> <a href="#"><i class="fa fa-comment-o text-muted mr-2"></i>8 Comments</a> </div>
                           </div>
                           <a href="blog-details.html" class="text-dark">
                              <h3 class="font-weight-semibold">At vero accusamus et iusto</h3>
                           </a>
                           <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat </p>
                           <div class="d-flex align-items-center pt-2 mt-auto">
                              <img src="<?php echo base_url() ?>assets/branch/images/users/male/6.jpg" class="avatar brround avatar-md mr-3" alt="avatar-img"> 
                              <div> <a href="profile.html" class="text-default">Loyd Nolf</a> <small class="d-block text-muted">15 days ago</small> </div>
                              <div class="ml-auto text-muted"> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fa fa-thumbs-o-up"></i></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="owl-item cloned" style="width: 375.337px; margin-right: 25px;">
                  <div class="item">
                     <div class="card mb-0">
                        <div class="item7-card-img"> <a href="#"></a> <img src="<?php echo base_url() ?>assets/branch/images/media/0-1.jpg" alt="img" class="cover-image"> </div>
                        <div class="card-body p-4">
                           <div class="item7-card-desc d-flex mb-2">
                              <a href="#"><i class="fa fa-calendar-o mr-2"></i>Dec-03-2018</a> 
                              <div class="ml-auto"> <a href="#"><i class="fa fa-comment-o mr-2"></i>4 Comments</a> </div>
                           </div>
                           <a href="blog-details.html" class="text-dark">
                              <h3 class="font-weight-semibold">Nemo enim ipsam voluptatem</h3>
                           </a>
                           <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat </p>
                           <div class="d-flex align-items-center pt-2 mt-auto">
                              <img src="<?php echo base_url() ?>assets/branch/images/users/male/5.jpg" class="avatar brround avatar-md mr-3" alt="avatar-img"> 
                              <div> <a href="profile.html" class="text-default">Joanne Nash</a> <small class="d-block text-muted">1 day ago</small> </div>
                              <div class="ml-auto text-muted"> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fa fa-thumbs-o-up"></i></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="owl-item cloned" style="width: 375.337px; margin-right: 25px;">
                  <div class="item">
                     <div class="card mb-0">
                        <div class="item7-card-img"> <a href="#"></a> <img src="<?php echo base_url() ?>assets/branch/images/media/0-2.jpg" alt="img" class="cover-image"> </div>
                        <div class="card-body p-4">
                           <div class="item7-card-desc d-flex mb-2">
                              <a href="#"><i class="fa fa-calendar-o mr-2"></i>Nov-28-2018</a> 
                              <div class="ml-auto"> <a href="#"><i class="fa fa-comment-o mr-2"></i>2 Comments</a> </div>
                           </div>
                           <a href="blog-details.html" class="text-dark">
                              <h3 class="font-weight-semibold">Sed ut perspiciatis unde iste</h3>
                           </a>
                           <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat </p>
                           <div class="d-flex align-items-center pt-2 mt-auto">
                              <img src="<?php echo base_url() ?>assets/branch/images/users/male/7.jpg" class="avatar brround avatar-md mr-3" alt="avatar-img"> 
                              <div> <a href="profile.html" class="text-default">Tanner Mallari</a> <small class="d-block text-muted">2 days ago</small> </div>
                              <div class="ml-auto text-muted"> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fa fa-thumbs-o-up"></i></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="owl-item cloned" style="width: 375.337px; margin-right: 25px;">
                  <div class="item">
                     <div class="card mb-0">
                        <div class="item7-card-img"> <a href="#"></a> <img src="<?php echo base_url() ?>assets/branch/images/media/0-3.jpg" alt="img" class="cover-image"> </div>
                        <div class="card-body p-4">
                           <div class="item7-card-desc d-flex mb-2">
                              <a href="#"><i class="fa fa-calendar-o mr-2"></i>Nov-19-2018</a> 
                              <div class="ml-auto"> <a href="#"><i class="fa fa-comment-o text-muted mr-2"></i>8 Comments</a> </div>
                           </div>
                           <a href="blog-details.html" class="text-dark">
                              <h3 class="font-weight-semibold">At vero eos et accusamus</h3>
                           </a>
                           <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat </p>
                           <div class="d-flex align-items-center pt-2 mt-auto">
                              <img src="<?php echo base_url() ?>assets/branch/images/users/female/15.jpg" class="avatar brround avatar-md mr-3" alt="avatar-img"> 
                              <div> <a href="profile.html" class="text-default">Aracely Bashore</a> <small class="d-block text-muted">5 days ago</small> </div>
                              <div class="ml-auto text-muted"> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a> <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fa fa-thumbs-o-up"></i></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="owl-nav"><button type="button" role="presentation" class="owl-prev"><span aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next"><span aria-label="Next">›</span></button></div>
         <div class="owl-dots disabled"></div>
      </div>
   </div>
</section>