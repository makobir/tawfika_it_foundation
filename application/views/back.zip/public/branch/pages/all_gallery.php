<div class="sptb bg-white">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="row">
               <div class="col-lg-3 col-md-12">
                  <div>
                      <img src="<?= base_url() ?>upload/slider/1.jpg" alt="Los Angeles">
                  </div>
               </div>
              
            </div>
         </div>
      </div>
   </div>
</div>

