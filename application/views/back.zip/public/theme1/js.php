
      <!-- Back To Top Button End -->
      <!-- ==== jQuery Library ==== -->
      <script src="<?= base_url() ?>assets/front/js/jquery-3.1.0.min.js"></script>
      <!-- ==== jQuery UI ==== -->
      <script src="<?= base_url() ?>assets/front/js/jquery-ui.min.js"></script>
      <!-- ==== jQuery UI Touch Punch Plugin ==== -->
      <script src="<?= base_url() ?>assets/front/js/jquery.ui.touch-punch.min.js"></script>
      <!-- ==== Bootstrap ==== -->
      <script src="<?= base_url() ?>assets/front/js/bootstrap.min.js"></script>
      <!-- ==== FakeLoader Plugin ==== -->
      <script src="<?= base_url() ?>assets/front/js/fakeLoader.min.js"></script>
      <!-- ==== StickyJS Plugin ==== -->
      <script src="<?= base_url() ?>assets/front/js/jquery.sticky.js"></script>
      <!-- ==== Owl Carousel Plugin ==== -->
      <script src="<?= base_url() ?>assets/front/js/owl.carousel.min.js"></script>
      <!-- ==== jQuery Tubuler Plugin ==== -->
      <script src="<?= base_url() ?>assets/front/js/jquery.tubular.1.0.js"></script>
      <!-- ==== Magnific Popup Plugin ==== -->
      <script src="<?= base_url() ?>assets/front/js/jquery.magnific-popup.min.js"></script>
      <!-- ==== jQuery Validation Plugin ==== -->
      <script src="<?= base_url() ?>assets/front/js/jquery.validate.min.js"></script>
      <!-- ==== Animate Scroll Plugin ==== -->
      <script src="<?= base_url() ?>assets/front/js/animatescroll.min.js"></script>
      <!-- ==== jQuery Waypoints Plugin ==== -->
      <script src="<?= base_url() ?>assets/front/js/jquery.waypoints.min.js"></script>
      <!-- ==== jQuery CounterUp Plugin ==== -->
      <script src="<?= base_url() ?>assets/front/js/jquery.counterup.min.js"></script>
      <!-- ==== jQuery CountDown Plugin ==== -->
      <script src="<?= base_url() ?>assets/front/js/jquery.countdown.min.js"></script>
      <!-- ==== RetinaJS ==== -->
      <script src="<?= base_url() ?>assets/front/js/retina.min.js"></script>
      <!-- ==== Main JavaScript ==== -->
      <script src="<?= base_url() ?>assets/front/js/main.js"></script>
      <script src="<?= base_url() ?>assets/front/js/custom.js"></script>