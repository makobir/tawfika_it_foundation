    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-full.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-theme.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-full-mobile.min.css" type="text/css" media="only screen and (max-width: 768px)" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-theme-mobile.min.css" type="text/css" media="only screen and (max-width: 768px)" />
    

    <div class="columns_wrap margin_bottom_2_5em_imp sc_columns columns_nofluid sc_columns_count_2 content_container gallery_item ">
    	<div class="column-1_1 sc_column_item sc_column_item_1 sc_info_st1 odd first ">
    		<div class="sc_section font_1_25em lh_1_3em">
    			<h4 style="display: inline-block">Scout Program</h4>
    			<hr>
    		</div>
	    </div>
    	<div class="column-1_3 sc_column_item sc_column_item_1 sc_info_st1 odd first ">
    		<div class="sc_section margin_bottom_2_5em_imp font_1_25em lh_1_3em">
    			<img src="<?= base_url() ?>upload/event/download.jpg">
    		</div>
    	</div>
    	<div class="column-1_3 sc_column_item sc_column_item_1 sc_info_st1 odd first ">
    		<div class="sc_section margin_bottom_2_5em_imp font_1_25em lh_1_3em">
    			<img src="<?= base_url() ?>upload/gallery/download (1).jpg">
    		</div>
    	</div>
    	<div class="column-1_3 sc_column_item sc_column_item_1 sc_info_st1 odd first ">
    		<div class="sc_section margin_bottom_2_5em_imp font_1_25em lh_1_3em">
    			<img src="<?= base_url() ?>upload/gallery/download (2).jpg">
    		</div>
    	</div>
    	<div class="column-1_3 sc_column_item sc_column_item_1 sc_info_st1 odd first ">
    		<div class="sc_section margin_bottom_2_5em_imp font_1_25em lh_1_3em">
    			<img src="<?= base_url() ?>upload/event/download.jpg">
    		</div>
    	</div>
    	<div class="column-1_3 sc_column_item sc_column_item_1 sc_info_st1 odd first ">
    		<div class="sc_section margin_bottom_2_5em_imp font_1_25em lh_1_3em">
    			<img src="<?= base_url() ?>upload/gallery/download (1).jpg">
    		</div>
    	</div>
    	<div class="column-1_3 sc_column_item sc_column_item_1 sc_info_st1 odd first ">
    		<div class="sc_section margin_bottom_2_5em_imp font_1_25em lh_1_3em">
    			<img src="<?= base_url() ?>upload/gallery/download (2).jpg">
    		</div>
    	</div>
    
    </div>
    
    <script>
        // Get the modal
        var modal = document.getElementById("myModal");
        
        // Get the button that opens the modal
        var btn = document.getElementById("myBtn");
        
        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];
        
        // When the user clicks the button, open the modal 
        btn.onclick = function() {
          modal.style.display = "block";
        }
        
        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
          modal.style.display = "none";
        }
        
        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
          if (event.target == modal) {
            modal.style.display = "none";
          }
        }
    </script>
    
    
    
    
    
    
    
    
    
    



