
<!-- Content without sidebar -->
<div class="page_content_wrap">
    <div class="content">
        <article class="post_item post_item_single page">
			<section class="post_content">
				<!-- Info section -->
				<div class="sc_section accent_top bg_tint_light sc_bg1" data-animation="animated fadeInUp normal">
					<div class="sc_section_overlay">
						<div class="sc_section_content">
							<div class="sc_content content_wrap margin_top_2_5em_imp margin_bottom_2_5em_imp">
								<h4 class="sc_title sc_title_regular sc_align_center margin_top_0 margin_bottom_085em text_center">Institute Name</h4>
								<div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
									<div class="column-1_2 sc_column_item sc_column_item_1 sc_info_st1 odd first ">
									    <div class="event-dt-img">
									        <img src="<?= base_url() ?>upload/about/about.jpg">
									    </div>
									    <p>is simply dummy text of the printing and 
									    typesetting industry. Lorem Ipsum has been
									    the industry's standard dummy text ever since 
									    the 1500s, when an unknown printer took a 
									    galley of type and scrambled it to make a 
									    type specimen book. It has survived not only
									    five centuries, but also the leap into 
									    electronic typesetting, remaining essentially
									    unchanged. It was popularised in the 1960s with
									    the release of Letraset sheets containing Lorem 
									    Ipsum passages, and more recently with desktop
									    publishing software like Aldus PageMaker 
									    including versions of Lorem Ipsum.</p>
									</div>
									<div class="column-1_2 sc_column_item sc_column_item_2 sc_info_st1 even">
										<div class="sc_section margin_bottom_2_5em_imp event_border font_1_25em lh_1_3em">
											<img src="<?= base_url() ?>upload/event/download.jpg">
											<h4 style="color:#376692;">TEST EVENT</h4>
											<p>Study, have fun, uncover a new passion or learn
											    have fun, uncover a new passionsimply dummy text 
											    skills that just may change your life.
											    <span class="event_btn"><a href="<?= base_url() ?>home/event_detail">Details</a></span>
											</p>
										</div>
										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /Info section -->