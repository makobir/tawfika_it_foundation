<div class="sc_content content_wrap margin_top_2_5em_imp margin_bottom_2_5em_imp">
   <h4 class="sc_title sc_title_regular sc_align_center margin_top_0 margin_bottom_085em text_center">Institute Founder</h4>
   <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
      <div class="column-1_2 sc_column_item sc_column_item_2 sc_info_st1 even">
         <img src="https://new.tawfika.edu.bd/upload/about/about.jpg">
      </div>
      <div class="column-1_2 sc_column_item sc_column_item_1 sc_info_st1 odd first ">
         <p>is simply dummy text of the printing and 
            typesetting industry. Lorem Ipsum has been
            the industry's standard dummy text ever since 
            the 1500s, when an unknown printer took a 
            galley of type and scrambled it to make a 
            type specimen book. It has survived not only
            five centuries, but also the leap into 
            electronic typesetting, remaining essentially
            unchanged. It was popularised in the 1960s with
            the release of Letraset sheets containing Lorem 
            Ipsum passages, and more recently with desktop
            publishing software like Aldus PageMaker 
            including versions of Lorem Ipsum.
         </p>
      </div>
   </div>
</div>