    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-full.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-theme.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-full-mobile.min.css" type="text/css" media="only screen and (max-width: 768px)" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-theme-mobile.min.css" type="text/css" media="only screen and (max-width: 768px)" />

			<!-- Content -->		
            <div class="page_content_wrap">
				<!-- Events calendar -->
                <div class="content_wrap">
                    <div class="content">
    					<div class="columns_wrap margin_bottom_2_5em_imp sc_columns columns_nofluid sc_columns_count_2">
    						<div class="column-1_2 sc_column_item sc_column_item_1 sc_info_st1 odd first result-pg ">
    							<div style="box-shadow:0 10px 40px 0 rgba(62, 57, 107, 0.1), 0 2px 9px 0 rgba(62, 57, 107, 0.1)" class="sc_section margin_bottom_2_5em_imp event_border font_1_25em lh_1_3em">
        							<form method="post" action="<?= base_url() ?>home/result_check">
                                      <label for="fname">Registration Number</label>
                                      <input style="border:1px solid red !important;" type="text" id="regi" name="regi"><br><br>
                                      <input type="submit" value="Submit">
                                    </form>
    							</div>
    						</div>
                        </div>
                     </div>
                    </div>
                </div>
				<!-- /Events calendar -->
				<!-- Related Posts Section -->
                <!--<section class="related_wrap scroll_wrap">
                    <div class="content_wrap">
                        <h2 class="section_title">Related Posts</h2>
                        <div class="sc_scroll_container sc_scroll_controls sc_scroll_controls_horizontal sc_scroll_controls_type_top">
                            <div class="sc_scroll sc_scroll_horizontal swiper-slider-container scroll-container" id="related_scroll">
                                <div class="sc_scroll_wrapper swiper-wrapper">
                                    <div class="sc_scroll_slide swiper-slide">
                                        <article class="post_item post_item_related post_item_1">
                                            <div class="post_content">
                                                <div class="post_content_wrap">
                                                    <h4 class="post_title">
														<a href="courses-streampage.html">All courses</a>
													</h4>
                                                </div>
                                            </div>
                                        </article>
                                        <article class="post_item post_item_related post_item_2">
                                            <div class="post_content">
                                                <div class="post_content_wrap">
                                                    <h4 class="post_title">
														<a href="video-tutorials.html">Video Tutorials</a>
													</h4>
                                                </div>
                                            </div>
                                        </article>
                                        <article class="post_item post_item_related post_item_3">
                                            <div class="post_content">
                                                <div class="post_content_wrap">
                                                    <h4 class="post_title">
														<a href="#">All Events</a>
													</h4>
                                                </div>
                                            </div>
                                        </article>
                                        <article class="post_item post_item_related post_item_4">
                                            <div class="post_content">
                                                <div class="post_content_wrap">
                                                    <h4 class="post_title">
														<a href="homepage-3.html">Homepage 3</a>
													</h4>
                                                </div>
                                            </div>
                                        </article>
                                    </div>
                                </div>
                                <div id="related_scroll_bar" class="sc_scroll_bar sc_scroll_bar_horizontal related_scroll_bar"></div>
                            </div>
                            <div class="sc_scroll_controls_wrap">
                                <a class="sc_scroll_prev" href="#"></a>
                                <a class="sc_scroll_next" href="#"></a>
                            </div>
                        </div>
                    </div>
                </section>-->
				<!-- /Related Posts Section -->
            </div>
            <!-- /Content -->