<!-- Content -->		
<div class="page_content_wrap">
	<!-- Events calendar -->
    <div class="content_wrap">
        <div class="content">
			<div class="columns_wrap margin_bottom_2_5em_imp sc_columns columns_nofluid sc_columns_count_2">
				<div class="column-1_2 sc_column_item sc_column_item_1 sc_info_st1 odd first result-pg ">
					<div style="box-shadow:0 10px 40px 0 rgba(62, 57, 107, 0.1), 0 2px 9px 0 rgba(62, 57, 107, 0.1)" class="sc_section margin_bottom_2_5em_imp event_border font_1_25em lh_1_3em">
						<form method="post" action="<?= base_url() ?>home/check_center">
                          <label for="fname">Center Code</label>
                          <input style="border:1px solid red !important;" type="text" id="code" name="code"><br><br>
                          <input type="submit" value="Submit">
                        </form>
					</div>
				</div>
            </div>
         </div>
        </div>
    </div>
</div>
<!-- /Content -->