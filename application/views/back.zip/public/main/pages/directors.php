
<!-- Content -->
<div class="page_content_wrap">
    <div class="content_wrap sc_hovers_st1">
        <div class="content">
            <article class="post_item post_item_single page">
                <section class="post_content">
                	<!-- Hover "Circle Effect 3" -->
					<div class="sc_section" data-animation="animated fadeInUp normal">
						<div class="sc_line sc_line_style_solid margin_top_0"></div>
						<div id="sc_blogger_3" class="sc_blogger layout_square_3 template_portfolio sc_blogger_horizontal sc_overflow_h_imp">
							<div class="isotope_wrap" data-columns="3">
								<div class="isotope_item isotope_item_square isotope_item_square_3 isotope_column_3">
									<div class="post_item post_item_square post_item_square_3 odd">
										<div class="post_content isotope_item_content ih-item colored circle effect3 left_to_right">
											<div class="post_featured img">
												<a href="post-without-sidebar.html">
													<img alt="" src="http://placehold.it/400x400"></a>
											</div>
											<div class="post_info_wrap info">
												<div class="info-back">
													<h4 class="post_title">
														<a href="post-without-sidebar.html">Introduction to Biomedical Imaging</a>
													</h4>
													<div class="post_descr">
														<p>
															<a href="post-without-sidebar.html">Sed ac egestas nisl. Sed vestibulum ac diam sit amet porta. Vivamus est neque, tristique quis...</a>
														</p>
														<a href="post-without-sidebar.html"><span class="hover_icon icon-plus-2"></span></a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="isotope_item isotope_item_square isotope_item_square_3 isotope_column_3">
									<div class="post_item post_item_square post_item_square_3 even">
										<div class="post_content isotope_item_content ih-item colored circle effect3 left_to_right">
											<div class="post_featured img">
												<a href="post-without-sidebar.html">
													<img alt="" src="http://placehold.it/400x400"></a>
											</div>
											<div class="post_info_wrap info">
												<div class="info-back">
													<h4 class="post_title">
														<a href="post-without-sidebar.html">Evaluating Social Programs</a></h4>
													<div class="post_descr">
														<p>
															<a href="post-without-sidebar.html">Duis bibendum commodo ultrices. Phasellus venenatis velit mauris, non sagittis tortor...</a>
														</p>
														<a href="post-without-sidebar.html"><span class="hover_icon icon-plus-2"></span></a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="isotope_item isotope_item_square isotope_item_square_3 isotope_column_3">
									<div class="post_item post_item_square post_item_square_3 post_format_gallery odd">
										<div class="post_content isotope_item_content ih-item colored circle effect3 left_to_right">
											<div class="post_featured img">
												<a href="post-gallery-format.html">
													<img alt="" src="http://placehold.it/400x400">
												</a>
											</div>
											<div class="post_info_wrap info">
												<div class="info-back">
													<h4 class="post_title">
														<a href="post-gallery-format.html">Principles of Written English, Part 1</a>
													</h4>
													<div class="post_descr">
														<p>
															<a href="post-gallery-format.html">Cras et fringilla lorem. Pellentesque habitant morbi tristique senectus et netus et malesuada...</a>
														</p>
														<a href="post-gallery-format.html"><span class="hover_icon icon-plus-2"></span></a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="isotope_item isotope_item_square isotope_item_square_3 isotope_column_3">
									<div class="post_item post_item_square post_item_square_3 even">
										<div class="post_content isotope_item_content ih-item colored circle effect3 left_to_right">
											<div class="post_featured img">
												<a href="#">
													<img alt="" src="http://placehold.it/400x400">
												</a>
											</div>
											<div class="post_info_wrap info">
												<div class="info-back">
													<h4 class="post_title">
														<a href="post-without-sidebar.html">Entrepreneurship 101:  Who is your customer?</a>
													</h4>
													<div class="post_descr">
														<p>
															<a href="post-without-sidebar.html">Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus...</a>
														</p>
														<a href="post-without-sidebar.html"><span class="hover_icon icon-plus-2"></span></a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="isotope_item isotope_item_square isotope_item_square_3 isotope_column_3">
									<div class="post_item post_item_square post_item_square_3 odd">
										<div class="post_content isotope_item_content ih-item colored circle effect3 left_to_right">
											<div class="post_featured img">
												<a href="post-without-sidebar.html">
													<img alt="" src="http://placehold.it/400x400"></a>
											</div>
											<div class="post_info_wrap info">
												<div class="info-back">
													<h4 class="post_title">
														<a href="post-without-sidebar.html">Introduction to Biomedical Imaging</a>
													</h4>
													<div class="post_descr">
														<p>
															<a href="post-without-sidebar.html">Sed orci dolor, pulvinar nec luctus a, malesuada ac nisl. Aliquam eleifend et dui et suscipit...</a>
														</p>
														<a href="post-without-sidebar.html"><span class="hover_icon icon-plus-2"></span></a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="isotope_item isotope_item_square isotope_item_square_3 isotope_column_3">
									<div class="post_item post_item_square post_item_square_3 even last">
										<div class="post_content isotope_item_content ih-item colored circle effect3 left_to_right">
											<div class="post_featured img">
												<a href="post-with-sidebar.html">
													<img alt="" src="http://placehold.it/400x400"></a>
											</div>
											<div class="post_info_wrap info">
												<div class="info-back">
													<h4 class="post_title">
														<a href="post-with-sidebar.html">Medical Chemistry: The  Molecular Basis</a>
													</h4>
													<div class="post_descr">
														<p>
															<a href="post-with-sidebar.html">Nulla dignissim nisi in nulla aliquet, eget sagittis est suscipit. Morbi quis diam nec libero...</a>
														</p>
														<a href="post-with-sidebar.html"> <span class="hover_icon icon-plus-2"></span></a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- /Hover "Circle Effect 3" -->
				</section>
			</article>
		</div>
	</div>
</div>