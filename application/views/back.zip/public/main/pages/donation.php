<div class="sc_section">
	<div class="sc_content content_wrap margin_top_3em_imp margin_bottom_3em_imp">
		<div class="columns_wrap sc_columns columns_fluid sc_columns_count_3">
			<div class=" column-1_3 sc_column_item sc_column_item_1 odd first text_center">
			    <div class="donat-bg">
    			    <div class="donat-img">
    			        <a href="https://www.agranibank.org/"><img src="<?= base_url() ?>upload/donation/abl_logo_new.png"></a>
    			    </div>
    				<div class="sc_section margin_top_1em_imp">
    					<p><a>Account Number: </a><br />
    						<a href="#">www.yoursite.com</a>
    					</p>
    				</div>
			    </div>
			</div>
			<div class=" column-1_3 sc_column_item sc_column_item_1 odd first text_center">
			    <div class="donat-bg">
    			    <div class="donat-img">
    			        <a href="https://www.agranibank.org/"><img src="<?= base_url() ?>upload/donation/abl_logo_new.png"></a>
    			    </div>
    				<div class="sc_section margin_top_1em_imp">
    					<p><a href="https://www.agranibank.org/">Account Number: </a><br />
    						<a href="#">www.yoursite.com</a>
    					</p>
    				</div>
			    </div>
			</div>
			<div class=" column-1_3 sc_column_item sc_column_item_1 odd first text_center">
			    <div class="donat-bg">
    			    <div class="donat-img">
    			        <a href="https://www.agranibank.org/"><img src="<?= base_url() ?>upload/donation/abl_logo_new.png"></a>
    			    </div>
    				<div class="sc_section margin_top_1em_imp">
    					<p><a href="https://www.agranibank.org/">Account Number: </a><br />
    						<a href="#">www.yoursite.com</a>
    					</p>
    				</div>
			    </div>
			</div>
		</div>
	</div>
</div>