    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-full.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-theme.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-full-mobile.min.css" type="text/css" media="only screen and (max-width: 768px)" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/events-calendar/tribe-events-theme-mobile.min.css" type="text/css" media="only screen and (max-width: 768px)" />
    
			<!-- Content -->		
            <div class="page_content_wrap">
				<!-- Events calendar -->
                <div class="content_wrap">
                    <div class="content">
                        <article class="post_item post_item_single page">
                            <div class="post_info">
                            </div>  
							<div class="columns_wrap margin_bottom_2_5em_imp sc_columns columns_nofluid sc_columns_count_2">
									<div class="column-1_1 sc_column_item sc_column_item_1 sc_info_st1 odd first ">
										<div class="sc_section mission_img margin_bottom_2_5em_imp event_border font_1_25em lh_1_3em">
											<img src="<?= base_url() ?>upload/mission/mission.jpg">
											<h4 style="color:#376692;">TEST Vision</h4>
											<p>Study, have fun, uncover a new passion or learn
											    have fun, uncover a new passionsimply dummy text 
											    skills that just may change your life. have fun, uncover a new passion or learn
											    have fun, uncover a new passionsimply dummy text 
											    skills that just may change your life. have fun, uncover a new passion or learn
											    have fun, uncover a new passionsimply dummy text 
											    skills that just may change your life.
											</p>
										</div>
									</div>
								</div>
                            </div>
                        </div>
                    </section>-->
                </article>
            </div>
        </div>