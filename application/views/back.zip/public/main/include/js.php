<script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery/jquery-migrate.min.js"></script>	
	<script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery/ui/core.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery/ui/widget.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery/ui/tabs.min.js"></script>
	<script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery/ui/accordion.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery/ui/effect.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery/ui/effect-fade.min.js"></script>
	<script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery/jquery.blockUI.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery/jquery.cookie.min.js"></script>
	
	<script type="text/javascript" src="<?= base_url() ?>assets/main/js/global.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/core.utils.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/core.init.min.js"></script>	
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/shortcodes/shortcodes.min.js"></script>	
	
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/rs-plugin/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/rs-plugin/jquery.themepunch.revolution.min.js"></script> 
	<script type="text/javascript" src="<?= base_url() ?>assets/main/js/slider_init.js"></script>

    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/superfish.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery.slidemenu.min.js"></script>

    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/mediaelement/mediaelement-and-player.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/mediaelement/wp-mediaelement.min.js"></script>

    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/core.messages/core.messages.min.js"></script>
    
	<script type="text/javascript" src="<?= base_url() ?>assets/main/js/jquery.isotope.min.js"></script>
	<script type="text/javascript" src="<?= base_url() ?>assets/main/js/hover/jquery.hoverdir.min.js"></script>
	<script type="text/javascript" src="<?= base_url() ?>assets/main/js/prettyPhoto/jquery.prettyPhoto.min.js"></script>		
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/swiper/idangerous.swiper-2.7.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/swiper/idangerous.swiper.scrollbar-2.4.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/diagram/chart.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>assets/main/js/functions.js"></script>
    