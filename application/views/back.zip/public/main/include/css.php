
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C300%2C400%2C600&#038;subset=latin%2Clatin-ext&#038;ver=4.3.1" type="text/css" media="all" />
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,400,400italic,700,700italic&#038;subset=latin,latin-ext,cyrillic,cyrillic-ext" type="text/css" media="all" />
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Love+Ya+Like+A+Sister:400&#038;subset=latin" type="text/css" media="all" />
	<link rel="stylesheet" href="<?= base_url() ?>assets/main/css/fontello/css/fontello.css" type="text/css" media="all" />
	
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/js/rs-plugin/settings.css" type="text/css" media="all" />

    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/woocommerce/woocommerce-layout.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/woocommerce/woocommerce-smallscreen.css" type="text/css" media="only screen and (max-width: 768px)" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/woocommerce/woocommerce.css" type="text/css" media="all" />

    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/style.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/shortcodes.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/core.animation.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/tribe-style.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/skins/skin.css" type="text/css" media="all" />

	<link rel="stylesheet" href="<?= base_url() ?>assets/main/css/core.portfolio.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/js/mediaelement/mediaelementplayer.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/js/mediaelement/wp-mediaelement.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/js/prettyPhoto/css/prettyPhoto.css" type="text/css" media="all" />	
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/js/core.customizer/front.customizer.css" type="text/css" media="all" />
	<link rel="stylesheet" href="<?= base_url() ?>assets/main/js/core.messages/core.messages.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/js/swiper/idangerous.swiper.min.css" type="text/css" media="all" />
	<link rel="stylesheet" href="<?= base_url() ?>assets/main/css/responsive.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/skins/skin-responsive.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/main/css/slider-style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="<?= base_url() ?>assets/main/css/custom-style.css" type="text/css" media="all" />
    
