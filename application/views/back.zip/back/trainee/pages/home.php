<div class="col-sm-12" style="margin-top: 10px;">
  <marquee> <?php $site = $this->Authenticator_model->setting_data();
   echo 'Welcome <b>'. $this->session->userdata('name') ?> </b></marquee>
</div>
<div class="col-sm-12">
  <div class="card card-primary">
    <div class="card-body">
      <div class="row">
        <div class="col-sm-1" style="font-size:20px; border-right: 2px solid green;">
          Task
        </div><!-- 
        <div class="col-sm-11" style="font-size:16px;">
          <?php if ($site->payment_id == NULL ) { ?> <a href="<?= base_url() ?>wallet/payfee">Registration Fee Payment </a> <?php } ?> | 
          <?php 
              $due = $this->Institute_model->dues();
              if($due->amount > 1) { ?>
    
          <a href="<?= base_url(); ?>wallet/payfee"> Formfillup Fee Payments  </a>
          <?php } ?>
        </div> -->
      </div>
    </div>
  </div>
</div>
<div class="col-sm-12">
  <div class="card card-primary">
    <div class="card-body">
      <div class="row">         
        <div class="col-sm-4" style="font-size:20px;">
          Payment Due : <strong>
            <?php 
              $due = $this->Institute_model->treaineepaid();
              $treaineefee = $this->Institute_model->treaineefee();
              echo $treaineefee->course_fee - $due->amount;
            ?>
              
            </strong>  
            ||
              <?php 
              $due = $this->Institute_model->treaineepaid();
              echo $due->amount;
            ?>
              

        </div>
        <div class="col-sm-4">
          
        </div>
      </div>
    </div>
  </div>
</div>
<!-- ./col -->
