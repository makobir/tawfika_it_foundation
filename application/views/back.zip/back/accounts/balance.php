<style type="text/css">
	.select2-selection__arrow {
    	height: 35px !important;
	}
</style>
<div class="card card-primary" style="width:100%;">
  <div class="card card-primary">
    <div class="card-body">
      <div class="row">
        <div class="col-sm-4" style="font-size:20px;">
          Admission Fee : <strong><?php          
          $fee = $this->Accounts_model->admissionfee(); 
          $total = $fee->course_fee+$fee->admission+$fee->registration+$fee->center+$fee->exam+$fee->others+$fee->practical;
          echo $total; 
          ?></strong>TK <a class="btn btn-default" href="<?= base_url() ?>accounts/balance_sheet">Check Now</a>
        </div>
        <div class="col-sm-4" style="font-size:20px;">
          Fee Collected : <strong>
            <?php 
              $collected = $this->Accounts_model->admissionfeecollected(); echo $collected->amount; 
            ?>
              
            </strong>  <a class="btn btn-default" href="<?= base_url(); ?>accounts/balance_sheet">Check Now</a>
        </div>
        <div class="col-sm-4">          
          Collection Due : <strong>
            <?php 
              echo $total - $collected->amount;
            ?>              
            </strong>  <a class="btn btn-default" href="<?= base_url(); ?>accounts/due">Check Now</a>
        </div>
      </div>
    </div>
  </div>
</div>
