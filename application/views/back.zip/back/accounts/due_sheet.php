<div class="row no-print" style="width: 100%">
   <div class="col-sm-12">
      <div class="card card-primary">
         <div class="card-body">
            <form method="post" action="<?= base_url() ?>accounts/due">
               <div class="row">
                  <div class="col-sm-3">
                     <div class="form-group">
                        <div class="input-group">
                           <div class="input-group-prepend">
                              <span class="input-group-text">
                              <i class="far fa-calendar-alt"></i>
                              </span>
                           </div>
                           <select name="scode" class="form-control" onchange="javascript:this.form.submit()">
                              <option value="">Select Month</option>
                              <?php $scode = $this->input->post('scode'); 
                              foreach ($this->Institute_model->session() as $key => $value) { ?>                              
                              <option <?php if($scode == $value->scode) { echo 'selected';} ?> value="<?= $value->scode; ?>"><?= $value->session; ?></option>
                              <?php } ?>
                           </select>
                        </div>
                     </div>
                  </div>
                  <div class="col-sm-2">
                     <div class="form-group">
                        <button type="submit" class="btn btn-info">View Report </button>
                     </div>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<?php 
   if ($this->input->post('scode') != NULL) {
     $scode = $this->input->post('scode');  
   }
   else {
     $scode = '';
   }
  
   ?>


   <div class="card card-primary" style="width:100%;">
  <div class="card card-primary">
    <div class="card-body">
    	<div class="col-sm-12">				
        <table id="example1" class="table table-bordered table-striped" >
          <thead>
             <tr>
               <th>SL</th>
               <th>ID</th>
               <th>Name</th>
               <th>Mobile</th>
               <th>Fee</th>
               <th>Paid</th>
               <th>Due</th>
             </tr>
          </thead>
          <tbody>
            <?php 
              $id = 1;
               foreach ($this->Accounts_model->trainee($scode) as $key => $value) {  
                $paid = $this->Accounts_model->paid($value->regi); 
                $fee = $this->Accounts_model->feedetails($value->regi);
                $total = $fee->course_fee+$fee->admission+$fee->registration+$fee->center+$fee->exam+$fee->others+$fee->practical ;
                if($total > $paid->amount ) {                  
            ?>
            <tr>
              <td><?php echo $id; ?></td>
              <td><?php echo $value->regi ?></td>
              <td><?php echo $value->name ?></td>
              <td><?php echo $value->mobile ?></td>
              <td>
                <?php 
                  echo $total; 
                ?>                  
              </td>
              <td>
                <?php 
                  echo $paid->amount; 
                ?>                  
              </td>
              <td><?php echo $fee->course_fee - $paid->amount ?></td>
            </tr>
            <?php $id++; } } ?>
          </tbody>
        </table>
			</div>
    </div>
  </div>
</div>