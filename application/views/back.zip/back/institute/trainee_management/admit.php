<style type="text/css">
 
table {
  border-collapse: collapse;
}



</style>
<div class="card card-primary" style="width:100%">    
	<div class="card-body" style="border:2px dotted; green;"> 


      <table width="100%">
         <tr style="margin-bottom:30px;">
            <td width="20%" height="102">
               <a href="#">
               <img src="<?php echo base_url() ?>upload/logo/logo.jpg" class="img_div" width="100" height="100"  alt=""/></a>
            </td>
            <td width="60%" align="center">
               <h1 style="margin:0"> 
                  Tawfika IT Foundation
               </h1>
               <h3 style="margin-bottom: 10px;">
               	Skill Development Training
               </h3>

               <lable style="border: 1px solid black; padding: 5px; border-radius: 10px; margin-bottom: 30px;"> Admit Card <b>  </b> </lable>
            </td>
            <td  width="20%" align="center">
               <img height="80px" src="<?php echo base_url() ?>upload/user/<?php echo $admit->userfile ?>"> <br>
            </td>
         </tr>
      </table>

      <table width="100%" border="0" cellpadding="0" cellspacing="0" style="margin-top:20px;"  >
         <tbody>
            <tr>
               <td width="15%" align="left" nowrap="nowrap">Code & Institute Name </td>
               <td width="1%" align="left" nowrap="nowrap">:</td>
               <td width="40%" align="left" nowrap="nowrap"><strong>( <?php echo $admit->code ?> )  <?php echo $admit->institute ?></strong></td>
               <td width="17%" align="left" nowrap="nowrap">Roll No </td>
               <td width="1%" align="left" nowrap="nowrap">:</td>
               <td width="30%" align="left" nowrap="nowrap"><strong ><?php echo $admit->roll ?></strong></td>
            </tr>
            <tr>
               <td align="left" nowrap="nowrap">Name of the Examinee</td>
               <td align="left" nowrap="nowrap">:</td>
               <td width="29%" align="left" nowrap="nowrap"><strong><?php echo $admit->name ?></strong></td>
               <td width="17%" align="left" nowrap="nowrap">Regi No </td>
               <td width="1%" align="left" nowrap="nowrap">:</td>
               <td width="40%" align="left" nowrap="nowrap"><strong > <?php echo $admit->regi ?></strong></td>
            </tr>
            <tr>
               <td align="left" nowrap="nowrap">Father's Name </td>
               <td align="left" nowrap="nowrap">:</td>
               <td align="left" nowrap="nowrap"><strong><?= $admit->father ?></strong></td>
               <td width="17%" align="left" nowrap="nowrap">Batch</td>
               <td align="left" nowrap="nowrap">:</td>
               <td align="left" nowrap="nowrap"><strong><?php echo $admit->batch ?></strong></td>
            </tr>
            <tr>
               <td align="left" nowrap="nowrap">Mother's Name</td>
               <td align="left" nowrap="nowrap">:</td>
               <td align="left" nowrap="nowrap"><strong><?= $admit->mother ?></strong></td>
               <td width="17%" align="left" nowrap="nowrap">Date of Birth</td>
               <td align="left" nowrap="nowrap">:</td>
               <td align="left" nowrap="nowrap"><strong><?php echo $admit->dob ?></strong></td>
            </tr>
            <tr>
               <td align="left" nowrap="nowrap">Trade Course</td>
               <td align="left" nowrap="nowrap">:</td>
               <td align="left" nowrap="nowrap"><strong><?php echo $admit->course ?> </strong></td>
               <td width="17%" align="left" nowrap="nowrap">Duration</td>
               <td align="left" nowrap="nowrap">:</td>
               <td align="left" nowrap="nowrap" ><strong><?php echo $admit->duration ?> Months </strong></td>
            </tr>
            <tr>
               <td align="left" nowrap="nowrap">Subjects</td>
               <td align="left" nowrap="nowrap">:</td>
               <td width="29%" align="left" nowrap="nowrap"><strong></strong></td>
            </tr>
         </tbody>
      </table>

      <table width="100%" border="0" cellpadding="0" cellspacing="0" style="margin-top:20px;"  >
         <tbody>
            <tr>
               <td width="15%" align="left" nowrap="nowrap">
               	<div class="row">
               		<div class="col-sm-2">
               			
               		</div>
               		<div class="col-sm-10">
               			<div class="row">
               				<?php $i = 1; foreach ($this->Exam_model->subjects($admit->regi) as $key => $value) { ?>
               				<div class="col-sm-6">
               					<?= $i .' : '. $value->title; ?>
               				</div>
               				<?php $i++; } ?>
               			</div>
               		</div>
               	</div>
               </td>
            </tr>


            <tr>
                <td colspan="4" style="text-align: right; padding-top: 30px; padding-right: 100px;">
                    Controller of Examinations
                </td>
            </tr>

            <tr>
                <td colspan="4">1. The examinee must bring the Registration Card along with the admit card in the examination hall. <br>
                2. The examinee must sign in the attendance sheet, otherwise examinee will be traeted as absent in the exam.  <br>
                3. Examnee must abide by the rules stated overleaf. </td>
            </tr>
        </table>
    </div>
</div>




