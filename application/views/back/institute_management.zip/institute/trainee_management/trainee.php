<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
   $(document).ready(function(){
       $('#purpose').on('change', function() {
         if ( this.value == '1')
         //.....................^.......
         {
              $("#sim").hide();
              $("#card").hide();
           $("#load").show();
         }
          else  
         {
           $("#load").hide();
           $("#sim").hide();
           $("#card").hide();
         }
       });
   });
</script>
<style type="text/css">

    #imagePreview,#imagePreview2 {
        width: 100px;
        height:100px;
        background-position: center center;
        background-size: cover;
        -webkit-box-shadow: 0 0 1px 1px rgba(0, 0, 0, .3);
        display: inline-block;
    </style>

<div class="card card-primary card-outline" style="width: 100%">
<div class="card-body">
<ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
   <li class="nav-item">
      <a class="nav-link <?php if($title == 'Admission') { echo 'active'; }?>"  id="custom-content-below-profile-tab" data-toggle="pill" href="#new" role="tab" aria-controls="custom-content-below-profile" aria-selected="false">Admission</a>
   </li>
   <li class="nav-item">
      <a class="nav-link <?php if($title == 'All Trainee') { echo 'active'; }?>" id="custom-content-below-home-tab" data-toggle="pill" href="#all" role="tab" aria-controls="custom-content-below-home" aria-selected="true">All Trainee</a>
   </li>

   <?php if($title == 'Edit Trainee') { ?> 
   <li class="nav-item">
      <a class="nav-link <?php if($title == 'Edit Trainee') { echo 'active'; }?>" id="custom-content-below-home-tab" data-toggle="pill" href="#edit" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Edit Trainee</a>
   </li>
   <?php } ?>
</ul>
<div class="tab-content" id="custom-content-below-tabContent">
   <?php if($title == 'Admission') { ?> 
   <div class="tab-pane fade <?php if($title == 'Admission') { echo 'show active'; }?>" id="new" role="tabpanel" aria-labelledby="custom-content-below-profile-tab">
      <div class="card card-primary" style="margin-top: 20px; width: 100%;">
         <?php if ($this->Authenticator_model->payments_status() != NULL) { ?>
         <div class="card-body">
            <form method="post" action="<?php echo base_url() ?>admission/update_info"  <?php echo form_open_multipart('upload/do_upload'); ?> 
            <input type="hidden" id="srt" name="type" placeholder="get value on option select">
            <div style="padding: 0px 20px;">
               <div class="formstyle">
                  <div class="col-md-12" style="background: #9ea09f; padding:7px 10px; font-weight: bold; ">
                     Course Information 
                  </div>
                  <div class="row">
                     <div class="col-md-3">
                        <div class="form-group">
                           <label></label>
                           <select class="form-control " name="session_id" id="course_id" required>
                              <option value="">Session</option>
                              <?php foreach ($this->Institute_model->session() as $key => $value) { 
                                 // $m = 10; //date('m');
                                 // // if($m == 1 or $m == 2 or $m == 3 or $m == 4 or $m == 5 or $m == 6 ){
                                 // //    $m =6;
                                 // // }
                                 // // elseif($m == 7 or $m == 8 or $m == 9 or $m == 10 or $m == 11 or $m == 12) {
                                 // //    $m = 12;
                                 // // }
                                 // if ($m <= $value->to) {
                                 //    if( $m >= $value->from ){
                                 ?>
                              <option value="<?php echo $value->scode ;?>" > <?php echo $value->session ;?>  </option>
                              <?php } ?>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label></label>
                           <select class="form-control " name="year" id="year" required>
                              <option>Year</option>
                              <option  value="2008">2008</option>
                              <option  value="2009">2009</option>
                              <option  value="2010">2010</option>
                              <option  value="2011">2011</option>
                              <option  value="2012">2012</option>
                              <option  value="2013">2013</option>
                              <option  value="2014">2014</option>
                              <option  value="2015">2015</option>
                              <option  value="2016">2016</option>
                              <option  value="2017">2017</option>
                              <option  value="2018">2018</option>
                              <option  value="2019">2019</option>
                              <option  value="2020">2020</option>
                              <option  value="2021">2021</option>
                              <option selected value="2022">2022</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label></label>
                           <select class="form-control " name="course_id" id="course_id" required>
                              <option value="">Select Course</option>
                              <?php foreach ($this->Institute_model->courses() as $key => $value) { ?>
                              <option value="<?php echo $value->id ;?>" > <?php echo $value->title ;?> </option>
                              <?php } ?>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label> </label>

                           <div class="input-group">
                              <div class="input-group-prepend">
                                 <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                              </div>
                              <input name="admission_date" id="admission_date" type="text" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd-mm-yyyy" data-mask>
                           </div>

                         <!--   <div class="input-group date" id="reservationdate" data-target-input="nearest">
                              <input type="text" class="form-control datetimepicker-input" data-target="#reservationdate" name="admission_date"/>
                              <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                                 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                              </div>
                           </div> -->
                        </div>
                     </div>
                  </div>
                  <div class="col-md-12" style="background: #9ea09f; padding:7px 10px; font-weight: bold;margin-bottom: 7px;">
                     Personal Information 
                  </div>
                  <div class="row" >
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Name : </label>
                           <input type="text" name="name" id="name" class="form-control" required   >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Father's Name : </label>
                           <input type="text"  name="father" id="father"  class="form-control" required>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Mother's Name : </label>
                           <input type="text" name="mother" id="mother" class="form-control" required  >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Date of Birth</label>
                           <div class="input-group">
                              <div class="input-group-prepend">
                                 <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                              </div>
                              <input name="dob" id="dob" type="text" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd-mm-yyyy" data-mask>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!--  Section 2  -->
                  <div class="row">
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Division</label>
                           <select class="form-control " name="division" id="division">
                              <option>Division</option>
                              <?php foreach ($this->Home_model->get_divisions() as $key => $value) { ?>
                              <option value="<?php echo $value->division ;?>" > <?php echo $value->division ;?> </option>
                              <?php } ?>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> District</label>
                           <select class="form-control " name="district" id="district">
                              <option>District</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Upazila</label>
                           <select class="form-control " name="upazila" id="upazila">
                              <option>Upazila</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Address</label>
                           <input type="text" name="address" id="address" class="form-control" required >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Mobile</label>
                           <input type="text" name="mobile" id="mobile" class="form-control"  minlength="11" maxlength="11" required >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Email</label>
                           <input type="email" name="email" id="email" class="form-control" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>NID</label>
                           <input type="number" name="nid" id="nid" class="form-control" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Birth Registration</label>
                           <input type="number" name="birth" id="bid" class="form-control" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Gender</label>
                           <select class="form-control" name="gender" required>
                              <option value="">Select</option>
                              <option value="Male">Male</option>
                              <option value="Female">Female</option>
                              <option value="Third Gender">Third Gender</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span>Religion</label>
                           <select class="form-control" name="religion" required>
                              <option value="">Select</option>
                              <option value="Islam">Islam</option>
                              <option value="Hinduism">Hinduism</option>
                              <option value="Christian">Christian</option>
                              <option value="Buddhism">Buddhism</option>
                              <option value="Others">Others</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Blod Groups</label>
                           <select class="form-control" name="blood">
                              <option value="">Select</option>
                              <option value="A(+)">A(+)</option>
                              <option value="A(-)">A(-)</option>
                              <option value="B(+)">B(+)</option>
                              <option value="B(-)">B(-)</option>
                              <option value="AB(+)">AB(+)</option>
                              <option value="AB(-)">AB(-)</option>
                              <option value="O(+)">O(+)</option>
                              <option value="O(-)">O(-)</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Register as Blood Donor ?</label>
                           <select class="form-control" name="donor">
                              <option value="">Select</option>
                              <option value="Yes">Yes</option>
                              <option value="No">No</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-12" style="background: #9ea09f; padding:7px 10px; font-weight: bold; margin-bottom: 7px;">
                        Academic Qualification 
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label>Select Exam</label>
                           <select class="form-control " name="exam[]" id="exam[]">
                              <option value="SSC">PSC</option>
                              <option value="SSC">JSC</option>
                              <option value="SSC">SSC/Equivalent</option>
                              <option value="HSC">HSC/Equivalent</option>
                              <option value="Honors/Equivalent">Honors/Equivalent</option>
                              <option value="Honors/Equivalent">Masters/Equivalent</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label>Roll</label>
                           <input type="number" name="roll[]" id="roll[]" class="form-control" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Board / University</label>
                           <select class="form-control" name="board[]">
                              <option value="Dhaka">Dhaka</option>
                              <option value="Rajshahi">Rajshahi</option>
                              <option value="Comilla">Comilla</option>
                              <option value="Jessore">Jessore</option>
                              <option value="Chittagong">Chittagong</option>
                              <option value="Barishal">Barishal</option>
                              <option value="Sylhet">Sylhet</option>
                              <option value="Dinajpur">Dinajpur</option>
                              <option value="Mymensingh">Mymensingh</option>
                              <option value="BOU">BOU</option>
                              <option value="Madrasah">Madrasah</option>
                              <option value="Technical">Technical</option>
                              <option value="National University">National University</option>
                              <option value="Others">Others</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label>Passing Year</label>
                           <input type="number" name="passing_year[]" id="passing_year[]" class="form-control" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Result</label>
                           <input type="text" name="result" id="result" class="form-control" placeholder="GPA"  >
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <select class="form-control " name="exam[]" id="exam[]">
                              <option value="SSC">PSC</option>
                              <option value="SSC">JSC</option>
                              <option value="SSC">SSC/Equivalent</option>
                              <option value="HSC">HSC/Equivalent</option>
                              <option value="Honors/Equivalent">Honors/Equivalent</option>
                              <option value="Honors/Equivalent">Masters/Equivalent</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <input type="number" name="roll[]" id="roll[]" class="form-control" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <select class="form-control" name="board[]">
                              <option value="Dhaka">Dhaka</option>
                              <option value="Rajshahi">Rajshahi</option>
                              <option value="Comilla">Comilla</option>
                              <option value="Jessore">Jessore</option>
                              <option value="Chittagong">Chittagong</option>
                              <option value="Barishal">Barishal</option>
                              <option value="Sylhet">Sylhet</option>
                              <option value="Dinajpur">Dinajpur</option>
                              <option value="Mymensingh">Mymensingh</option>
                              <option value="BOU">BOU</option>
                              <option value="Madrasah">Madrasah</option>
                              <option value="Technical">Technical</option>
                              <option value="National University">National University</option>
                              <option value="Others">Others</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <input type="number" name="passing_year[]" id="passing_year[]" class="form-control" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <input type="text" name="result[]" id="result[]" class="form-control" placeholder="GPA"  >
                        </div>
                     </div>
                     <div class="col-md-12" style="background: #9ea09f; padding:7px 10px; font-weight: bold;margin-bottom: 7px;">
                        Media Information
                     </div>

                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Gurdian</label>
                           <input type="text" name="gurdian" id="gurdian" class="form-control" >
                        </div>
                        <div class="form-group">
                           <label>Relation with trainee</label>                           
                           <select class="form-control" name="relation">
                              <option value="">Select</option>
                              <option value="Father">Father</option>
                              <option value="Mother">Mother</option>
                              <option value="Spouse">Spouse</option>
                              <option value="Brother / Sister">Brother / Sister</option>
                              <option value="Others">Others</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Mobile</label>
                           <input type="text" name="gurdian_mobile" id="mobile" class="form-control"  minlength="11" maxlength="11" required >
                        </div>
                        <div class="form-group">
                           <label>BTEB Student ?</label>
                           <select class="form-control" name="bteb">
                              <option value="">Select</option>
                              <option value="Yes">Yes</option>
                              <option value="No">No</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> PP size Photo (< 100 KB)</label>
                           <input name="userfile" id="uploadFile" type="file" class="form-control" accept=".jpg">
                        </div>
                        <div id="imagePreview" class="well" ></div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>NID / Birth Regi (<200 KB)</label>
                           <input name="userfile2" id="uploadFile2" type="file" class="form-control" accept=".jpg">
                        </div>
                        <div id="imagePreview2" class="well"></div>
                     </div>
                  </div>
               </div>
               <center>
                  <hr style="margin:0; margin-top:5px; padding:5px;">
                  <button type="reset" class="btn btn-info" value="Reset">Reset</button>
                  <button type="submit" name="submit" class="btn btn-success"> Admit Now</button>
                  <center>
                     <!-- <input type="submit" value="সাবমিট" class="btn btn-success"> -->
                  </center>
               </center>
            </div>
            </form>
         </div>
         <?php } else { ?>
         <div class="card-body">               
            <a href="<?= base_url() ?>wallet/payfee">Please pay Registration Fee for activated ! <span class="btn btn-info">Pay Now</span> </a>
         </div>
         <?php } ?>  
      </div>
   </div>
   <?php } ?>
   <div class="tab-pane fade <?php if($title == 'All Trainee') { echo 'show active'; }?>" id="all" role="tabpanel" aria-labelledby="custom-content-below-profile-tab">
      <div class="card card-primary">
         <div class="card-body">
            <div style="margin-top: 20px;">
               <table id="example1" class="table table-bordered table-striped" >
                  <thead>
                     <tr class="text-center">
                        <th>SL</th>
                        <th>Name</th>
                        <th>Regi</th>
                        <th>Roll</th>
                        <th>Course</th>
                        <th>Mobile</th>
                        <th>Result</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php $i=1; if($this->Institute_model->all_trainee() != NULL){ foreach ($this->Institute_model->all_trainee() as $key => $t) { ?>
                     <tr class="text-center">
                        <td><?php echo $i; ?></td>
                        <td><?php echo $t->name; ?></td>
                        <td><?php echo $t->regi; ?></td>
                        <td><?php echo $t->roll; ?></td>
                        <td><?php echo $t->course; ?></td>
                        <td><?php echo $t->mobile; ?></td>
                        <td><?php echo $t->result; ?></td>
                        <td>
                           <div class="btn-group">
                              <a href="<?= base_url() ?>institute/trainee/<?php echo $t->regi; ?>" class="btn btn-default"> <i class="fa fa-eye"></i> </a>
                              <?php $check = $this->Institute_model->exam_enroll_check($t->regi); ?>
                              <a href="<?= base_url() ?>institute/edit/<?php echo $t->regi; ?>" class="btn btn-default <?php if($check != NULL) { echo 'disabled';} ?>" > <i class="fa fa-edit"></i></a>

                              <a href="<?= base_url() ?>institute/registration/<?php echo $t->regi; ?>" class="btn btn-default"> <i class="fa fa-id-card"></i></a>
                              <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal<?php echo $t->regi ?>"><i class="fa fa-trash"></i></button>       
                           </div>
                        </td>
                     </tr>
                     <?php $i++; } } ?>
                  </tbody>
                  <tfoot>
                  </tfoot>
               </table>
            </div>
         </div>
      </div>
   </div>
   <?php if($title == 'Edit Trainee') { ?> 
   <div class="tab-pane fade <?php if($title == 'Edit Trainee') { echo 'show active'; }?>" id="edit" role="tabpanel" aria-labelledby="custom-content-below-profile-tab">
      <div class="card card-primary" style="margin-top: 20px; width: 100%;">       
         <div class="card-body">
            <form method="post" action="<?php echo base_url() ?>admission/update_info"  <?php echo form_open_multipart('upload/do_upload'); ?> 
            <input type="hidden" name="regi" value="<?php echo $trainee->regi ;?>" >
            <div style="padding: 0px 20px;">
               <div class="formstyle">
                  <div class="col-md-12" style="background: #9ea09f; padding:7px 10px; font-weight: bold; ">
                     Course Information 
                  </div>
                  <div class="row">
                     <div class="col-md-3">
                        <div class="form-group">
                           <label></label>
                           <select class="form-control " name="session_id" id="course_id" required>
                              <option value="">Session</option>
                              <?php foreach ($this->Institute_model->session() as $key => $value) { ?>
                              <option <?php if($trainee->session == $value->scode) {echo 'selected';}?> value="<?php echo $value->scode ;?>" > <?php echo $value->session ;?>  </option>
                              <?php } ?>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label></label>
                           <select class="form-control " name="year" id="year" required>
                              <option>Year</option>
                              <option <?php if($trainee->year == '2008') {echo 'selected';}?> value="2008">2008</option>
                              <option <?php if($trainee->year == '2009') {echo 'selected';}?> value="2009">2009</option>
                              <option <?php if($trainee->year == '2010') {echo 'selected';}?> value="2010">2010</option>
                              <option <?php if($trainee->year == '2011') {echo 'selected';}?> value="2011">2011</option>
                              <option <?php if($trainee->year == '2012') {echo 'selected';}?> value="2012">2012</option>
                              <option <?php if($trainee->year == '2013') {echo 'selected';}?> value="2013">2013</option>
                              <option <?php if($trainee->year == '2014') {echo 'selected';}?> value="2014">2014</option>
                              <option <?php if($trainee->year == '2015') {echo 'selected';}?> value="2015">2015</option>
                              <option <?php if($trainee->year == '2016') {echo 'selected';}?> value="2016">2016</option>
                              <option <?php if($trainee->year == '2017') {echo 'selected';}?> value="2017">2017</option>
                              <option <?php if($trainee->year == '2018') {echo 'selected';}?> value="2018">2018</option>
                              <option <?php if($trainee->year == '2019') {echo 'selected';}?> value="2019">2019</option>
                              <option <?php if($trainee->year == '2020') {echo 'selected';}?> value="2020">2020</option>
                              <option <?php if($trainee->year == '2021') {echo 'selected';}?> value="2021">2021</option>
                              <option <?php if($trainee->year == '2022') {echo 'selected';}?> value="2022">2022</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label></label>
                           <select class="form-control " name="course_id" id="course_id" required>
                              <option value="">Select Course</option>
                              <?php foreach ($this->Institute_model->courses() as $key => $value) { ?>
                              <option <?php if($trainee->course_id == $value->id) {echo 'selected';}?>  value="<?php echo $value->id ;?>" > <?php echo $value->title ;?> </option>
                              <?php } ?>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label> </label>
                           <div class="input-group">
                              <div class="input-group-prepend">
                                 <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                              </div>
                              <input name="admission_date" id="admission_date" type="text" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd-mm-yyyy" data-mask value="<?= $trainee->admission_date; ?>">
                              
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-12" style="background: #9ea09f; padding:7px 10px; font-weight: bold;margin-bottom: 7px;">
                     Personal Information 
                  </div>
                  <div class="row" >
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Name : </label>
                           <input type="text" name="name" id="name" class="form-control" value="<?= $trainee->name; ?>"   >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Father's Name : </label>
                           <input type="text"  name="father" id="father"  class="form-control" value="<?= $trainee->father; ?>">
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Mother's Name : </label>
                           <input type="text" name="mother" id="mother" class="form-control" value="<?= $trainee->mother; ?>"  >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Date of Birth</label>
                           <div class="input-group">
                              <div class="input-group-prepend">
                                 <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                              </div>
                              <input name="dob" id="dob" type="text" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd-mm-yyyy" data-mask value="<?= $trainee->dob; ?>">
                           </div>
                        </div>
                     </div>
                  </div>

                  <div class="row">
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Division</label>
                           <select class="form-control " name="division" id="division">
                              <option>Division</option>
                              <?php foreach ($this->Home_model->get_divisions() as $key => $value) { ?>
                              <option value="<?php echo $value->division ;?>" > <?php echo $value->division ;?> </option>
                              <?php } ?>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> District</label>
                           <select class="form-control " name="district" id="district">
                              <option>District</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Upazila</label>
                           <select class="form-control " name="upazila" id="upazila">
                              <option>Upazila</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Address</label>
                           <input type="text" name="address" id="address" class="form-control" value="<?= $trainee->address; ?>" required >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Mobile</label>
                           <input type="text" name="mobile" id="mobile" class="form-control"  minlength="11" maxlength="11" required value="<?= $trainee->mobile; ?>" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Email</label>
                           <input type="email" name="email" id="email" class="form-control" value="<?= $trainee->email; ?>" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>NID</label>
                           <input type="number" name="nid" id="nid" class="form-control" value="<?= $trainee->nid; ?>" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Birth Registration</label>
                           <input type="number" name="birth" id="bid" class="form-control" value="<?= $trainee->birth; ?>" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Gender</label>
                           <select class="form-control" name="gender" required>
                              <option value="">Select</option>
                              <option <?php if($trainee->gender == 'Male') {echo 'selected';}?> value="Male">Male</option>
                              <option <?php if($trainee->gender == 'Female') {echo 'selected';}?> value="Female">Female</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span>Religion</label>
                           <select class="form-control" name="religion" required>
                              <option value="">Select</option>
                              <option <?php if($trainee->religion == 'Islam') {echo 'selected';}?>  value="Islam">Islam</option>
                              <option <?php if($trainee->religion == 'Hinduism') {echo 'selected';}?>  value="Hinduism">Hinduism</option>
                              <option <?php if($trainee->religion == 'Christian') {echo 'selected';}?>  value="Christian">Christian</option>
                              <option <?php if($trainee->religion == 'Buddhism') {echo 'selected';}?>  value="Buddhism">Buddhism</option>
                              <option <?php if($trainee->religion == 'Others') {echo 'selected';}?>  value="Others">Others</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Blod Groups</label>
                           <select class="form-control" name="blood">
                              <option value="">Select</option>
                              <option <?php if($trainee->blood == 'A(+)') {echo 'selected';}?>  value="A(+)">A(+)</option>
                              <option <?php if($trainee->blood == 'A(-)') {echo 'selected';}?>  value="A(-)">A(-)</option>
                              <option <?php if($trainee->blood == 'B(+)') {echo 'selected';}?>  value="B(+)">B(+)</option>
                              <option <?php if($trainee->blood == 'B(-)') {echo 'selected';}?>  value="B(-)">B(-)</option>
                              <option <?php if($trainee->blood == 'AB(+)') {echo 'selected';}?>  value="AB(+)">AB(+)</option>
                              <option <?php if($trainee->blood == 'AB(-)') {echo 'selected';}?>  value="AB(-)">AB(-)</option>
                              <option <?php if($trainee->blood == 'O(+)') {echo 'selected';}?>  value="O(+)">O(+)</option>
                              <option <?php if($trainee->blood == 'O(-)') {echo 'selected';}?>  value="O(-)">O(-)</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Register as Blood Donor</label>
                           <select class="form-control" name="donor">
                              <option value="">Select</option>
                              <option value="Yes">Yes</option>
                              <option value="No">No</option>
                           </select>
                        </div>
                     </div>
                   <!--   <div class="col-md-12" style="background: #9ea09f; padding:7px 10px; font-weight: bold; margin-bottom: 7px;">
                        Academic Qualification 
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label>Select Exam</label>
                           <select class="form-control " name="exam[]" id="exam[]">
                              <option value="SSC">PSC</option>
                              <option value="SSC">JSC</option>
                              <option value="SSC">SSC/Equivalent</option>
                              <option value="HSC">HSC/Equivalent</option>
                              <option value="Honors/Equivalent">Honors/Equivalent</option>
                              <option value="Honors/Equivalent">Masters/Equivalent</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label>Roll</label>
                           <input type="number" name="roll[]" id="roll[]" class="form-control" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Board / University</label>
                           <select class="form-control" name="board[]">
                              <option value="Dhaka">Dhaka</option>
                              <option value="Rajshahi">Rajshahi</option>
                              <option value="Comilla">Comilla</option>
                              <option value="Jessore">Jessore</option>
                              <option value="Chittagong">Chittagong</option>
                              <option value="Barishal">Barishal</option>
                              <option value="Sylhet">Sylhet</option>
                              <option value="Dinajpur">Dinajpur</option>
                              <option value="Mymensingh">Mymensingh</option>
                              <option value="BOU">BOU</option>
                              <option value="Madrasah">Madrasah</option>
                              <option value="Technical">Technical</option>
                              <option value="National University">National University</option>
                              <option value="Others">Others</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label>Passing Year</label>
                           <input type="number" name="passing_year[]" id="passing_year[]" class="form-control" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Result</label>
                           <input type="text" name="result" id="result" class="form-control" placeholder="GPA"  >
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <select class="form-control " name="exam[]" id="exam[]">
                              <option value="SSC">PSC</option>
                              <option value="SSC">JSC</option>
                              <option value="SSC">SSC/Equivalent</option>
                              <option value="HSC">HSC/Equivalent</option>
                              <option value="Honors/Equivalent">Honors/Equivalent</option>
                              <option value="Honors/Equivalent">Masters/Equivalent</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <input type="number" name="roll[]" id="roll[]" class="form-control" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <select class="form-control" name="board[]">
                              <option value="Dhaka">Dhaka</option>
                              <option value="Rajshahi">Rajshahi</option>
                              <option value="Comilla">Comilla</option>
                              <option value="Jessore">Jessore</option>
                              <option value="Chittagong">Chittagong</option>
                              <option value="Barishal">Barishal</option>
                              <option value="Sylhet">Sylhet</option>
                              <option value="Dinajpur">Dinajpur</option>
                              <option value="Mymensingh">Mymensingh</option>
                              <option value="BOU">BOU</option>
                              <option value="Madrasah">Madrasah</option>
                              <option value="Technical">Technical</option>
                              <option value="National University">National University</option>
                              <option value="Others">Others</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <input type="number" name="passing_year[]" id="passing_year[]" class="form-control" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <input type="text" name="result[]" id="result[]" class="form-control" placeholder="GPA"  >
                        </div>
                     </div> -->
                     <div class="col-md-12" style="background: #9ea09f; padding:7px 10px; font-weight: bold;margin-bottom: 7px;">
                        Media Information
                     </div>          
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>Gurdian</label>
                           <input type="text" name="gurdian" id="gurdian" class="form-control"  value="<?= $trainee->gurdian; ?>">
                        </div>
                        <div class="form-group">
                           <label>Relation with trainee</label>                           
                           <select class="form-control" name="relation">
                              <option value="">Select</option>
                              <option <?php if($trainee->relation == 'Father') {echo 'selected';}?> value="Father">Father</option>
                              <option <?php if($trainee->relation == 'Mother') {echo 'selected';}?> value="Mother">Mother</option>
                              <option <?php if($trainee->relation == 'Spouse') {echo 'selected';}?> value="Spouse">Spouse</option>
                              <option <?php if($trainee->relation == 'Brother / Sister') {echo 'selected';}?> value="Brother / Sister">Brother / Sister</option>
                              <option <?php if($trainee->relation == 'Others') {echo 'selected';}?> value="Others">Others</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> Mobile</label>
                           <input type="text" name="gurdian_mobile" id="mobile" class="form-control"  minlength="11" maxlength="11"  value="<?= $trainee->gurdian_mobile; ?>" >
                        </div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label><span style="color:red;">*</span> PP size Photo (< 100 KB)</label>
                           <input name="userfile" id="uploadFile" type="file" class="form-control" accept=".jpg">
                        </div>
                        <div id="imagePreview" class="well" > <img width="50px" src="<?php echo base_url() ?>upload/user/<?= $trainee->userfile; ?>"></div>
                     </div>
                     <div class="col-md-3">
                        <div class="form-group">
                           <label>NID / Birth Regi (<200 KB)</label>
                           <input name="userfile2" id="uploadFile2" type="file" class="form-control" accept=".jpg">
                        </div>
                        <div id="imagePreview2" class="well" ><img width="50px" src="<?php echo base_url() ?>upload/document/<?= $trainee->userfile2; ?>"></div>
                     </div>
                  </div>
               </div>
               <center>
                  <hr style="margin:0; margin-top:5px; padding:5px;">
                  <button type="submit" name="submit" class="btn btn-success"> Update Now</button>
                  <center>
                     <!-- <input type="submit" value="সাবমিট" class="btn btn-success"> -->
                  </center>
               </center>
            </div>
            </form>
         </div> 
      </div>
   </div> 
   <?php } ?>
</div>
<script src="<?php echo base_url() ?>assets/back/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript">
   $(document).ready(function(){
    $('#division').change(function(){
     var division = $('#division').val();
     if(division != '')
     {
      $.ajax({
       url:"<?php echo site_url()?>home/fetch_district",
       method:"POST",
       data:{division:division},
       success:function(data)
       {
        $('#district').html(data);
       }
      });
     }
     else
     {
      $('#district').html('<option value="">Select</option>');
     }
    });
   
    $('#district').change(function(){
     var district = $('#district').val();
     if(district != '')
     {
      $.ajax({
       url:"<?php echo site_url()?>home/fetch_upazila",
       method:"POST",
       data:{district:district},
       success:function(data)
       {
        $('#upazila').html(data);
       }
      });
     }
     else
     {
      $('#upazila').html('<option value="">Select</option>');
     }
    });
   
    $('#upazila').change(function(){
     var upazila = $('#upazila').val();
     if(upazila != '')
     {
      $.ajax({
       url:"<?php echo site_url()?>home/fetch_union",
       method:"POST",
       data:{upazila:upazila},
       success:function(data)
       {
        $('#union').html(data);
       }
      });
     }
     else
     {
      $('#union').html('<option value="">Select</option>');
     }
    });
   
    $('#union').change(function(){
     var union = $('#union').val();
     if(union != '')
     {
      $.ajax({
       url:"<?php echo site_url()?>home/fetch_village",
       method:"POST",
       data:{union:union},
       success:function(data)
       {
        $('#village').html(data);
       }
      });
     }
     else
     {
      $('#village').html('<option value="">Select</option>');
     }
    });
   
    $('#union').change(function(){
     var union = $('#union').val();
     if(union != '')
     {
      $.ajax({
       url:"<?php echo site_url()?>home/fetch_post",
       method:"POST",
       data:{union:union},
       success:function(data)
       {
        $('#post').html(data);
       }
      });
     }
     else
     {
      $('#post').html('<option value="">Select</option>');
     }
    });
   
   });
</script>
<script>
   function run() {
       document.getElementById("srt").value = document.getElementById("Ultra").value;
   }
</script>

    <script type="text/javascript">
        $(function () {
            $("#uploadFile").on("change", function ()
            {
                var files = !!this.files ? this.files : [];
                if (!files.length || !window.FileReader)
                    return; // no file selected, or no FileReader support

                if (/^image/.test(files[0].type)) { // only image file
                    var reader = new FileReader(); // instance of the FileReader
                    reader.readAsDataURL(files[0]); // read the local file

                    reader.onloadend = function () { // set image data as background of div
                        $("#imagePreview").css("background-image", "url(" + this.result + ")");
                    }
                }
            });
        });
    </script>    
    <script type="text/javascript">
        $(function () {
            $("#uploadFile2").on("change", function ()
            {
                var files = !!this.files ? this.files : [];
                if (!files.length || !window.FileReader)
                    return; // no file selected, or no FileReader support

                if (/^image/.test(files[0].type)) { // only image file
                    var reader = new FileReader(); // instance of the FileReader
                    reader.readAsDataURL(files[0]); // read the local file

                    reader.onloadend = function () { // set image data as background of div
                        $("#imagePreview2").css("background-image", "url(" + this.result + ")");
                    }
                }
            });
        });
    </script>



<?php 
   foreach ($this->Institute_model->all_trainee() as $key => $value) {
?>
<div class="modal fade" id="exampleModal<?php echo $value->regi ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Confirm</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Do you want to delete this ? 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary left" data-dismiss="modal">No</button>
        <a href="<?= base_url() ?>institute/delete_trainee/<?php echo $value->regi ?>" type="button" class="btn btn-danger">Yes</a>
      </div>
    </div>
  </div>
</div>
<?php } ?>