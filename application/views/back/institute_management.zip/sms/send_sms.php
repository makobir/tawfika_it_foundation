

<div class="card card-primary card-outline" style="width:100%;">
	<div class="card-header">
		Send SMS 
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-sm-3" >
				Balance : <b> 
				<?php
				$homepage = file_get_contents('http://api.greenweb.com.bd/g_api.php?token=18677c9556a641c202072e06285856fa&balance');
				$num = $homepage ;
				$int = (int)$num;
				$float = (float)$num;
				echo number_format ($float,2);
				?>TK = <?php echo number_format($float / 0.20); ?> SMS</b>
			</div>
			<div class="col-sm-3" >
				SMS Expired : <b> 
				<?php
				$homepage = file_get_contents('http://api.greenweb.com.bd/g_api.php?token=18677c9556a641c202072e06285856fa&expiry');
				echo $homepage;
				?></b>
			</div>
			<div class="col-sm-3">
				SMS Sent : <b>
				<?php
				$homepage = file_get_contents('http://api.greenweb.com.bd/g_api.php?token=18677c9556a641c202072e06285856fa&tokensms');
				echo $homepage;
				?></b>
			</div>
			<div class="col-sm-3">
				Total SMS Send :<b> 
				<?php
			$homepage = file_get_contents('http://api.greenweb.com.bd/g_api.php?token=18677c9556a641c202072e06285856fa&totalsms');
				echo $homepage;
				?></b>
			</div>
		</div>		
		<!-- <iframe src="http://api.greenweb.com.bd/g_api.php?token=18677c9556a641c202072e06285856fa&expiry&rate&tokensms&totalsms"></iframe> -->
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-sm-6">
				<form method="post" action="<?= base_url() ?>super_admin/sms">
				<div class="card card-primary">
					<div class="card-body">						
						<div class="form-group">
							<label>To</label>
							<input class="form-control" type="" name="phone" placeholder="01713576258,01911143338,.....">
						</div>
						<div class="form-group">					
							<label>Message <span style="color:red;"> Please avoid Banglish SMS</span></label>
							<textarea class="form-control" name="message"></textarea>
						</div>
						<div class="form-group">
							<button class="btn btn-info" type="submit">Send</button>
						</div>
					</div>
				</div>
				</form>
			</div>
			<div class="col-sm-6">
				<div class="card card-primary">
					<div class="card-body">	
						<form method="post" action="<?= base_url() ;?>super_admin/send_sms">
						<div class="row">
							<div class="form-group col-sm-4">
								<select name="session" class="form-control">
									<option value="">Select Session</option>
									<?php foreach ($this->Super_admin_model->session() as $key => $value) { ?>						
									<option value="<?php echo $value->scode; ?>" <?php if($this->input->post('session') == $value->scode) {echo 'selected';} ?>><?= $value->session; ?></option>
									<?php } ?>
								</select>
							</div>	
							<div class="form-group col-sm-4">
								<select name="year" class="form-control">
									<option value="">Select Year</option>
									<option value='2021'>2021</option>
									<option value='2022'>2022</option>
								</select>
							</div>	
							<div class="form-group col-sm-4">
								<select name="course" class="form-control"  onchange="javascript:this.form.submit()">
									<option value="">Select Course</option>
									<?php foreach ($this->Super_admin_model->course() as $key => $value) { ?>						
									<option value="<?php echo $value->id; ?>" <?php if($this->input->post('course') == $value->id) {echo 'selected';} ?> ><?= $value->title; ?></option>
									<?php } ?>
								</select>
							</div>	
						</form>
						</div>									
						<div class="form-group">
						<form method="post" action="<?= base_url() ;?>super_admin/sms">
							<select  name="phone" class="form-control">
								<option>Select Recipient</option>
								<option value="<?php
								$session = $this->input->post('session');
								$course = $this->input->post('course');	
								$year = $this->input->post('year');									
								 foreach ($this->Super_admin_model->trainee_list($session,$course,$year) as $key => $value) { echo $value->mobile.',';}
								?>">All</option>
								<?php
								$session = $this->input->post('session');
								$course = $this->input->post('course');								
								$year = $this->input->post('year');								
								 foreach ($this->Super_admin_model->trainee_list($session,$course,$year) as $key => $v) { 
								?>						
								<option value="<?= $v->mobile ?>"><?= $v->name ?></option>
								<?php } ?>
							</select>
							
						</div>
						<div class="form-group">					
							<label>Message</label>
							<textarea name="message" class="form-control"></textarea>
						</div>
						<div class="form-group">
							<button class="btn btn-info" type="submit">Send</button>
						</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>