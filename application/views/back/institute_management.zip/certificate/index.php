
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/certificate/style.css">
<div class="container">
  <img src="<?php echo base_url() ?>assets/certificate/x.png" alt="Snow" style="width:100%;">
  <img class="qrcoad" src="<?php echo base_url() ?>assets/certificate/qr.png" alt="qr coad">

    <div class="Serial-No">110024</div>
    <div class="Serial-No">110024</div>
    <div class="roll"><?php echo $exam->roll ?></div>
    <div class="session"><?php echo $exam->session ?> / <?php echo $exam->year ?></div>
    <div class="reg"><?php echo $admit->regi ?></div>
    <div class="subject"><?php echo $admit->course ?> </div>
    <div class="name"><?php echo $admit->name ?></div>
    <div class="fathersname"><?php echo $admit->father ?></div>
    <div class="mothersname"><?php echo $admit->mother ?></div>
    <div class="month"><?php echo $admit->duration ?></div>
    <div class="form-to"><?php echo $admit->from ?></div>
    <div class="left-at"><?php echo $admit->to ?></div>
    <div class="right-at"><?php echo $admit->site_name ?></div>
    <div class="gpa"><?php
                   if($this->Exam_model->resultss($admit->regi) != NULL){ 
                   $t = $this->Exam_model->resultss($admit->regi);                   
                  ?>
                 <b>
                     
                     <?php 
                        if($t->mcq >= 36) {
                           $total_mark = $t->mcq + $t->attendance + $t->typing +  $t->viva + $t->practical;
                           if($total_mark >= 180 ) { echo 'A+';}
                           elseif($total_mark >= 160 ) { echo 'A';}
                           elseif($total_mark >= 140 ) { echo 'A-';}
                           elseif($total_mark >= 120 ) { echo 'B';}
                           elseif($total_mark <= 119 ) { echo 'Failed';}
                        }else {
                           echo "Failed";
                        }
                     ?>               
                  <?php }else { echo 'No Results Found!';} ?></div>
    <div class="issue">15-20-2021</div>
   <span class="tik1">&#x2611;</span>
   <span class="tik2">&#x2611;</span>
   <span class="tik3">&#x2611;</span>
   <span class="tik4">&#x2611;</span>



</div>