<style type="text/css">

.footer_text {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 10px;
  color: #666666;
  line-height: 15px;
}
.bar_bk {

  background-image: url(../images/bar_bk.jpg);
  background-repeat: repeat-x;
}
#site_title {
font-family:Verdana, Arial, Helvetica, sans-serif;
color:#FFFFEE; 
margin:3px 0px 0px 5px;
font-size:17px;
}
#site_title_des {
font-family: Verdana, Arial, Helvetica, sans-serif; 
font-size:17px; 
color:white; 
margin:0px; 
margin-left:6px; 
display:block; 
margin:0px 0px 5px 5px;
}
.left_round {
  background-image: url(../images/left_round.gif);
  background-repeat: no-repeat;
  background-position: left top;
}
.black11 {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 11px;
  color: #000000;
  text-decoration: none;
  font-weight: normal;
}
.red11 {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 11px;
  color: #F00;
  text-decoration: none;
  font-weight: normal;
}
.red12bold {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 11px;
  color: #F00;
  text-decoration: none;
  font-weight: bold;
}


.black12bold {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 12px;
  color: #000000;
  text-decoration: none;
  font-weight: bold;
}
.black12 {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 12px;
  color: #000000;
  text-decoration: none;
  font-weight: normal;
}

.black14bold {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 14px;
  color: #000000;
  text-decoration: none;
  font-weight: bold;
  clip: rect(auto,auto,auto,auto);
}
.black14 {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 14px;
  color: #000000;
  text-decoration: none;
  font-weight: normal;
  clip: rect(auto,auto,auto,auto);
}


.black16bold {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 16px;
  color: #000000;
  text-decoration: none;
  font-weight: bold;
}

.links {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 11px;
  color: #00F;
  text-decoration: none;
  font-weight: bold;
}
.links02 {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 11px;
  color: #FFF;
  text-decoration: none;
  font-weight: normal;
}

.links:hover {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 11px;
  color: #F00;
  text-decoration: none;
  font-weight: bold;
}
.links02:hover {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 11px;
  color: #0C9;
  text-decoration: none;
  font-weight: normal;
}
.vfield {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 22px;
  color: #000;
  text-decoration: none;
  background-color: #F4F0F2;
  border: 1px solid #999;
  font-weight: bold;
  width: 200px;
  padding-top: 4px;
  padding-right: 4px;
  padding-left: 4px;
  padding-bottom: 4px;
  border-radius: 4px;
}

.textfield01 {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 22px;
  color: #ACD0A1;
  text-decoration: none;
  background-color: #E4EDE4;
  border: 1px solid #C3C5C5;
  font-weight: bold;
  width: 180px;
  padding-top: 4px;
  padding-right: 4px;
  padding-left: 4px;
  padding-bottom: 4px;
  border-radius: 4px;
}

.textfield05 {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 12px;
  color: #000000;
  text-decoration: none;
  background-color: #F4F0F2;
  border: 1px solid #999;
  font-weight: normal;
  width: 205px;
  padding-top: 4px;
  padding-right: 4px;
  padding-left: 4px;
  padding-bottom: 4px;
  border-radius: 4px;
}
.textfield06 {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 12px;
  color: #000000;
  text-decoration: none;
  background-color: #F4F0F2;
  border: 1px solid #999;
  font-weight: normal;
  width: 200px;
  padding-top: 4px;
  padding-right: 4px;
  padding-left: 4px;
  padding-bottom: 4px;
  border-radius: 4px;
}
td, th {
    /* border: 1px solid #001117;
</style>

<table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
   <tbody>
      <tr>
         <td>
            <table width="750" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" style="margin-top:20px;">
               <tbody>
                  <tr>
                     <td align="left" valign="top" background="./Education Board Bangladesh_files/back_left.gif">&nbsp;</td>
                     <td valign="top">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                           <tbody>
                              <tr>
                                 <td width="142" height="121" align="center" valign="middle" bgcolor="#EEEEEE" class="left_round">
                                    <img src="<?= base_url() ?>upload/logo/logo.jpg" width="140" height="140">
                                 </td>
                                 <td width="2">
                                   
                                 </td>
                                 <td valign="top" bgcolor="#007814">
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                       <tbody>
                                          <tr>
                                             <td align="right">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                   <tbody>
                                                      <tr>
                                                         <td align="left" valign="bottom" style=" padding-left: 10px;" >
                                                            <h1 id="site_title_des">Govt. Approved</h1>
                                                         </td>
                                                         <td align="right" valign="top">
                                                           
                                                          </td>
                                                      </tr>
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                          <tr>
                                             <td align="left" bgcolor="#479e55">
                                                <img src="./Education Board Bangladesh_files/trans.gif" width="1" height="1">
                                             </td>
                                          </tr>
                                          <tr>
                                             <td height="55" align="left">
                                                <h1 style="color: white; padding-left: 10px;" >Towfika IT Foundation</h1>
                                             </td>
                                          </tr>
                                          <tr>
                                             <td align="right">
                                                <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                                </table>
                                             </td>
                                          </tr>
                                          <tr>
                                             <td align="left" bgcolor="#FFFFFF" style=" padding-left: 10px;" >
                                                Regi No : 
                                             </td>
                                          </tr>
                                          <tr>
                                             <td height="23" align="right" bgcolor="#86C775" class="bar_bk"></td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                        <img src="./Education Board Bangladesh_files/trans.gif" width="1" height="1">
                     </td>
                     <td align="right" valign="top" background="./Education Board Bangladesh_files/back_right.gif">&nbsp;</td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
      <tr>
         <td>
            <table width="750" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
               <tbody>
                  <tr>
                     <td width="12" align="left" valign="top" background="./Education Board Bangladesh_files/back_left.gif">&nbsp;</td>
                     <td valign="top">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                           <tbody>
                              <tr>
                                 <td height="50" align="center" valign="middle" class="black16bold">SSC/Dakhil/Equivalent Result 2006</td>
                              </tr>
                              <tr>
                                 <td align="center" valign="middle">
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                       <tbody>
                                          <tr>
                                             <td align="center" valign="middle">
                                                <table width="100%" border="0" cellpadding="3" cellspacing="1" class="black12">
                                                   <tbody>
                                                      <tr>
                                                         <td width="12%" align="left" valign="middle" bgcolor="#EEEEEE">Roll No</td>
                                                         <td width="27%" align="left" valign="middle" bgcolor="#EEEEEE"><?= $tarinee->roll ?></td>
                                                         <td width="22%" align="left" valign="middle" bgcolor="#EEEEEE">Name</td>
                                                         <td width="39%" align="left" valign="middle" bgcolor="#EEEEEE"><?= $tarinee->name; ?></td>
                                                      </tr>
                                                      <tr>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Registration</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $tarinee->regi; ?></td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Father's Name</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $tarinee->father; ?></td>
                                                      </tr>
                                                      <tr>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Course</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $tarinee->title; ?></td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Mother's Name</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $tarinee->mother; ?></td>
                                                      </tr>
                                                      <tr>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Dutration</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $tarinee->duration; ?> Month</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Date of Birth</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $tarinee->dob; ?></td>
                                                      </tr>
                                                      <tr>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Result</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE" class="black12bold"></td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Institute</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $tarinee->institute; ?></td>
                                                      </tr>
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                          <tr>
                                             <td height="40" align="center" valign="middle"><span class="black16bold">Grade Sheet</span></td>
                                          </tr>
                                          <tr>
                                             <td align="center" valign="middle">
                                                <table width="100%" border="0" cellpadding="3" cellspacing="1" class="black12">
                                                   <tbody>
                                                      <tr class="black12bold">
                                                         <td width="19%" align="left" valign="middle" bgcolor="#AFB7BE">Code</td>
                                                         <td width="66%" align="left" valign="middle" bgcolor="#AFB7BE">Subject</td>
                                                         <td width="15%" align="left" valign="middle" bgcolor="#AFB7BE">Grade</td>
                                                      </tr>
                                                      <?php foreach ($subject_result as $key => $value) { ?>
                                                      <tr>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $value->scode; ?></td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $value->title; ?></td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">
                                                            <?php 
                                                               $result_check = $this->Exam_model->result($value->id); 
                                                               if(isset($result_check)) {
                                                                  $obtain = $result_check->correct_ans;
                                                                  $total = $result_check->total_ques; 
                                                                //  echo $total*90/100;
                                                                  if($obtain >= $total*90/100) { echo 'A+';}
                                                                  elseif($obtain >= ($total*80/100) ) { echo 'A';}
                                                                  elseif($obtain >= ($total*70/100) ) { echo 'A-';}
                                                                  elseif($obtain >= ($total*60/100) ) { echo 'B';}
                                                                  elseif($obtain <= ($total*59/100) ) { echo 'Failed';}
                                                               } else {
                                                                  echo 'Not Found';
                                                               } 
                                                            ?>
                                                         </td>
                                                      </tr>
                                                      <?php } ?>
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                          <tr>
                                             <td height="40" align="center" valign="middle"><span class="black16bold">Others</span></td>
                                          </tr>
                                          <tr>
                                             <td align="center" valign="middle">
                                                <table width="100%" border="0" cellpadding="3" cellspacing="1" class="black12">
                                                   <tbody>
                                                      <tr class="black12bold">
                                                         <td width="19%" align="left" valign="middle" bgcolor="#AFB7BE">Code</td>
                                                         <td width="66%" align="left" valign="middle" bgcolor="#AFB7BE">Subject</td>
                                                         <td width="15%" align="left" valign="middle" bgcolor="#AFB7BE">Grade</td>
                                                      </tr>
                                                      <?php 
                                                         $marks = $this->Exam_model->exam_marks();
                                                         if($marks != null) { ?>
                                                      <tr>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $value->scode; ?></td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Attendance</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">
                                                            <?php 
                                                               $exam_marks = $this->Exam_model->exam_marks();
                                                               $obtain =  $exam_marks->attendance;
                                                               $total = 20; 
                                                               if($obtain >= $total*90/100) { echo 'A+';}
                                                               elseif($obtain >= ($total*80/100) ) { echo 'A';}
                                                               elseif($obtain >= ($total*70/100) ) { echo 'A-';}
                                                               elseif($obtain >= ($total*60/100) ) { echo 'B';}
                                                               elseif($obtain <= ($total*59/100) ) { echo 'Failed';}
                                                            ?>
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $value->scode; ?></td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Typing</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">
                                                            <?php 
                                                               $exam_marks = $this->Exam_model->exam_marks();
                                                               $obtain =  $exam_marks->typing;
                                                               $total = 30; 
                                                               if($obtain >= $total*90/100) { echo 'A+';}
                                                               elseif($obtain >= ($total*80/100) ) { echo 'A';}
                                                               elseif($obtain >= ($total*70/100) ) { echo 'A-';}
                                                               elseif($obtain >= ($total*60/100) ) { echo 'B';}
                                                               elseif($obtain <= ($total*59/100) ) { echo 'Failed';}
                                                            ?>
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $value->scode; ?></td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Viva</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">
                                                            <?php 
                                                               $exam_marks = $this->Exam_model->exam_marks();
                                                               $obtain =  $exam_marks->viva;
                                                               $total = 10; 
                                                               if($obtain >= $total*90/100) { echo 'A+';}
                                                               elseif($obtain >= ($total*80/100) ) { echo 'A';}
                                                               elseif($obtain >= ($total*70/100) ) { echo 'A-';}
                                                               elseif($obtain >= ($total*60/100) ) { echo 'B';}
                                                               elseif($obtain <= ($total*59/100) ) { echo 'Failed';}
                                                            ?>
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE"><?= $value->scode; ?></td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">Practical</td>
                                                         <td align="left" valign="middle" bgcolor="#EEEEEE">
                                                            <?php 
                                                               $exam_marks = $this->Exam_model->exam_marks();
                                                               $obtain =  $exam_marks->practical;
                                                               $total = 80; 
                                                               if($obtain >= $total*90/100) { echo 'A+';}
                                                               elseif($obtain >= ($total*80/100) ) { echo 'A';}
                                                               elseif($obtain >= ($total*70/100) ) { echo 'A-';}
                                                               elseif($obtain >= ($total*60/100) ) { echo 'B';}
                                                               elseif($obtain <= ($total*59/100) ) { echo 'Failed';}
                                                            ?>
                                                         </td>
                                                      </tr>
                                                      <?PHP } ?>
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>

                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                        </table>
                     </td>
                     <td width="12" align="right" valign="top" background="./Education Board Bangladesh_files/back_right.gif">&nbsp;</td>
                  </tr>
                  <tr>
                     <td align="left" valign="top" background="./Education Board Bangladesh_files/back_cor_left_bot.gif"><img src="./Education Board Bangladesh_files/trans.gif" width="12" height="12"></td>
                     <td valign="top" background="./Education Board Bangladesh_files/back_bot.gif"><img src="./Education Board Bangladesh_files/trans.gif" width="12" height="12"></td>
                     <td align="right" valign="top" background="./Education Board Bangladesh_files/back_cor_right_bot.gif"><img src="./Education Board Bangladesh_files/trans.gif" width="12" height="12"></td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
      <tr>
         <td>&nbsp;</td>
      </tr>
   </tbody>
</table>
</body></html>