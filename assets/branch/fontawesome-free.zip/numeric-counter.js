$(function(e){
	$('.counter').countUp();
});